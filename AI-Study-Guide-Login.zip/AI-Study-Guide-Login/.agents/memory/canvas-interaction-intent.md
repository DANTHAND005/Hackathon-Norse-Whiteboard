---
name: Canvas interaction intent
description: Preserve mouse controls without letting canvas hover hijack page scrolling.
---

The user wants mouse interaction on the whiteboard after a deliberate click, not permanently disabled wheel controls. Merely hovering over it should still allow page scrolling. The hand control must offer a return to mouse selection.

Keep one mouse/hand switch beside the drawing hot bar, not duplicate hand and mouse icons within the hot bar. Trackpad gestures must pan the board in both directions after clicking the canvas; engagement should persist until the user explicitly leaves it by clicking elsewhere or pressing Escape.

In the compact layout, the mouse/hand switch and Library/book control must align in the same vertical column, including when Chat Summary is open.

**Why:** The user repeatedly refined the scroll fix to retain trackpad panning while preventing accidental canvas movement during page scrolling, and explicitly requested a single separate mouse/hand switch.

**How to apply:** Preserve click-to-engage behavior when revising the editor or input controls. Do not solve scroll conflicts by disabling canvas mouse support entirely.

Prefer gating the editor's native wheel handling over reimplementing viewport movement through scene updates.

**Why:** Engagement state alone previously appeared correct while the rendered diagram stayed stationary. Native gesture handling coordinates viewport animations and zoom as well as translation.

**How to apply:** For scroll changes, verify actual rendered diagram movement in both axes and unchanged document scroll while engaged; then verify document scrolling resumes after release.