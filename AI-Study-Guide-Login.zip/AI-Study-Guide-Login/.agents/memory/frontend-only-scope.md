---
name: Frontend-only scope
description: Preview scope with separate Gemini and key-free live-audio exceptions.
---

Keep Norse Whiteboard frontend-only. Do not add real authentication, API calls, AI, file uploads, sharing, or persisted board/account data unless the user explicitly expands the scope.

The user explicitly expanded scope on 2026-10-02 to connect Ask AI to Gemini 3.6 Flash. A stateless server-side AI endpoint is allowed for this feature only; this does not authorize authentication, board persistence, or cloud sync.

The Study together live-audio feature remains part of the desired product scope. Use key-free browser-to-browser audio unless the user explicitly chooses a credentialed provider. Room coordination is permitted for this exception, but it does not authorize account authentication, recordings, persistent uploads, or synchronization of whiteboard edits.

**Why:** The user repeatedly requested frontend-only implementation for the login and the post-login whiteboard.

**Why for live audio:** On 2026-10-02, after asking to remove audio options, the user clarified that they still want to work on Study together and need a walkthrough. They previously required avoiding provider API keys.

**How to apply:** Keep features outside the explicit exceptions as local previews. Do not remove audio solely on the basis of the superseded withdrawal request. Explain audio separately from board synchronization, and never call the free LiveKit plan key-free. Never imply credentials or user content were sent or saved when they were not.