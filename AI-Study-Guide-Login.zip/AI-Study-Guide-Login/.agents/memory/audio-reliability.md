---
name: Audio reliability expectations
description: Distinguish confirmed audio transmission from recovery and real-world network coverage.
---

A successful steady-state, two-browser audio test is not evidence that microphone connections survive interruptions or work between different networks.

**Why:** The user reported repeated microphone disconnections after an automated native-WebRTC transmission test passed, and explicitly asked to fix those disconnects.

**How to apply:** When changing audio recovery, verify interrupted signaling and immediate local mute/leave behavior, not only connected labels or normal transmission. Explain whether verification used synthetic microphone input or physical devices. Do not describe same-environment browser tests as proof of unrestricted cross-network connectivity; direct-only audio can still need a relay on restrictive networks.