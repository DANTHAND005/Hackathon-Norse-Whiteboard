import { useState } from 'react';
import { Users, ArrowRight } from 'lucide-react';
import './_current.css';
const prompts = [
  {
    id: 'jake-observer', person: 'JAKE · circled on p.2', page: 2,
    question: 'Why not just call update()?',
    answer: 'You could, but then the subject has to know every class that cares about it. notify() loops over a list instead, so new observers plug in without touching the subject. I sketched it below.',
  },
  {
    id: 'aaron-subject', person: 'AARON · p.2', page: 2,
    question: 'Subject vs Observer, which one holds the list?',
    answer: 'The Subject keeps the observer list. Observers subscribe or unsubscribe; when its state changes, the Subject notifies each one.',
  },
  {
    id: 'daniel-missed', person: 'DANIEL · p.1', page: 1,
    question: 'Explain this page like I missed the lecture',
    answer: 'This sample page introduces the Observer pattern: one object broadcasts a change to several interested listeners.',
  },
  {
    id: 'daniel-quiz', person: 'DANIEL · p.1', page: 1,
    question: 'Quiz me on the 3 patterns',
    answer: 'Sample prompt: Which pattern lets observers subscribe to updates from a subject? Answer: Observer.',
  },
];


export function Current(){ const [message,setMessage]=useState(''); const setSelectedPrompt=(p:typeof prompts[number])=>setMessage(p.question); const selectPage=(_page:number,_scroll:boolean)=>{}; const setActiveSection=(_section:string)=>{}; return <main className='board-page' style={{padding:32}}><p style={{fontSize:12,marginBottom:20}}>Current Community · extracted from the app</p><section className="destination-panel" aria-labelledby="community-heading">
            <div className="destination-heading">
              <span className="destination-icon"><Users size={20} /></span>
              <div>
                <h2 id="community-heading">Community preview</h2>
                <p>Choose a sample discussion to open its page on the board.</p>
              </div>
            </div>
            <div className="community-list">
              {prompts.map((prompt) => (
                <button
                  className="community-item"
                  key={prompt.id}
                  type="button"
                  onClick={() => {
                    setSelectedPrompt(prompt);
                    selectPage(prompt.page, false);
                    setActiveSection('whiteboard');
                  }}
                  data-testid={`button-community-${prompt.id}`}
                >
                  <span className="history-meta">{prompt.person}</span>
                  <strong>{prompt.question}</strong>
                  <small>Open page {prompt.page} on the whiteboard <ArrowRight size={13} /></small>
                </button>
              ))}
            </div>
          </section>{message && <p role='status'>Sample discussion: {message}</p>}</main>; }
