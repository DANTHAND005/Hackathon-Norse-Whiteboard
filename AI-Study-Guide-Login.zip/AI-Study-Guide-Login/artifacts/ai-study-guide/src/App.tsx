import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import Whiteboard from '@/pages/whiteboard';
import { ArrowRight, Eye, EyeOff } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<'signin' | 'create'>('signin');
  const [visiblePassword, setVisiblePassword] = useState(false);
  const [message, setMessage] = useState<{ kind: 'error' | 'info'; text: string } | null>(null);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get('email') ?? '').trim();
    const password = String(data.get('password') ?? '');
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setMessage({ kind: 'error', text: 'Add a valid email address and we’ll take it from there.' });
      return;
    }
    if (!password || (mode === 'create' && password.length < 8)) {
      setMessage({
        kind: 'error',
        text: mode === 'create' ? 'Use at least 8 characters for your password.' : 'Enter your password to continue.',
      });
      return;
    }
    event.currentTarget.reset();
    setLocation('/whiteboard');
  }

  function switchMode() {
    setMode(mode === 'signin' ? 'create' : 'signin');
    setMessage(null);
  }

  function showHelp() {
    setMessage({ kind: 'info', text: 'Norse Whiteboard account help is not connected in this preview.' });
  }

  return (
    <main className="study-shell">
      <section className="welcome-pane" aria-label="Sign in to Norse Whiteboard">
        <div className="welcome-main">
          <a className="brand-lockup" href="/" aria-label="Norse Whiteboard home" data-testid="link-home">
            <img
              className="school-logo"
              src={`${import.meta.env.BASE_URL}norse-whiteboard-logo.jpeg`}
              alt="Norse school mascot"
            />
            <span className="brand-name">Norse Whiteboard</span>
          </a>
          <div className="eyebrow">Your ideas. Your game plan.</div>
          <h1 className="welcome-title">{mode === 'signin' ? 'Welcome back!' : 'Start with a blank board.'}</h1>
          <p className="welcome-copy">Sign in to pick up where you left off.</p>
          <h2 className="form-heading">{mode === 'signin' ? 'Sign in to your board' : 'Create your Norse Whiteboard'}</h2>
          <form onSubmit={handleSubmit} noValidate data-testid="form-signin">
            <label className="field-label" htmlFor="email">School email</label>
            <div className="field-wrap">
              <input className="study-input" id="email" name="email" type="email" autoComplete="email" placeholder="you@somewhere.com" aria-label="School email" data-testid="input-email" onChange={() => setMessage(null)} />
            </div>
            <label className="field-label" htmlFor="password">
              <span>Password</span>
              {mode === 'signin' && <button className="forgot-button" type="button" onClick={() => setMessage({ kind: 'info', text: 'Password reset is not connected in this preview. No email has been sent.' })} data-testid="button-forgot-password">Forgot?</button>}
            </label>
            <div className="field-wrap">
              <input className="study-input password-input" id="password" name="password" type={visiblePassword ? 'text' : 'password'} autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} placeholder={mode === 'signin' ? 'Your password' : 'At least 8 characters'} aria-label="Password" data-testid="input-password" onChange={() => setMessage(null)} />
              <button className="show-password" type="button" onClick={() => setVisiblePassword(!visiblePassword)} aria-label={visiblePassword ? 'Hide password' : 'Show password'} data-testid="button-toggle-password">
                {visiblePassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <button className="submit-button" type="submit" data-testid="button-submit">
              {mode === 'signin' ? 'Continue to your board' : 'Create your board'} <ArrowRight size={17} />
            </button>
            {message && <div className={`form-message ${message.kind}`} role="status" data-testid="status-form-message">{message.text}</div>}
          </form>
          <p className="mode-line">
            {mode === 'signin' ? 'New to Norse Whiteboard?' : 'Already have a board?'}
            <button className="mode-toggle" type="button" onClick={switchMode} data-testid="button-toggle-mode">{mode === 'signin' ? 'Create an account' : 'Sign in instead'}</button>
          </p>
          <div className="privacy-note">A clear place for your next big idea.</div>
          <footer className="welcome-footer">
            <span>© 2026 Norse Whiteboard</span>
            <div className="footer-links">
              <button type="button" onClick={showHelp} data-testid="button-help">Help</button>
              <button type="button" onClick={() => setMessage({ kind: 'info', text: 'Privacy details will appear here when the full product is available.' })} data-testid="button-privacy">Privacy</button>
            </div>
          </footer>
        </div>
      </section>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/whiteboard" component={Whiteboard} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
