import { type FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowUpRight, BookOpen, CalendarDays, Check, ChevronDown, CircleHelp, Clock3,
  Filter, Flag, MapPin, MessageCircle, MoreHorizontal, Plus, Search, Send,
  Users, X,
} from 'lucide-react';
import './community.css';

import { seedSessions, allTags, initialConversations, threadSamples, type Session, type Conversation } from './community-data';

type DialogName = 'create' | 'report' | null;
type CommunityProps = { active?: boolean; onHome: () => void; onProfile: () => void };
export function Community({ active = true, onHome, onProfile }: CommunityProps) {
  const [sessions, setSessions] = useState(seedSessions);
  const [selectedId, setSelectedId] = useState(seedSessions[0].id);
  const [query, setQuery] = useState('');
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [liveOnly, setLiveOnly] = useState(false);
  const [tagOpen, setTagOpen] = useState(false);
  const [mobileTab, setMobileTab] = useState<'sessions' | 'messages' | 'details'>('sessions');
  const [conversations, setConversations] = useState(initialConversations);
  const [selectedConversation, setSelectedConversation] = useState('sarah');
  const [draft, setDraft] = useState('');
  const [localMessages, setLocalMessages] = useState<Record<string, { name: string; text: string; time: string; mine?: boolean }[]>>({});
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [hiddenConversation, setHiddenConversation] = useState<Conversation | null>(null);
  const [dialog, setDialog] = useState<DialogName>(null);
  const [reportTarget, setReportTarget] = useState<Conversation | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [attached, setAttached] = useState<string[]>([]);
  const [toast, setToast] = useState('');
  const [formError, setFormError] = useState('');
  const dialogRef = useRef<HTMLDialogElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const [newTitle, setNewTitle] = useState('');
  const [newCourse, setNewCourse] = useState('');
  const [newPlace, setNewPlace] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newMax, setNewMax] = useState('4');
  const [newTag, setNewTag] = useState('Study group');
  const selected = sessions.find((session) => session.id === selectedId) ?? sessions[0];
  const activeConversation = conversations.find((conversation) => conversation.id === selectedConversation);
  const thread = [...(threadSamples[selectedConversation] ?? []), ...(localMessages[selectedConversation] ?? [])];
  const filtered = useMemo(() => sessions.filter((session) => {
    const text = `${session.title} ${session.course} ${session.place} ${session.host} ${session.tags.join(' ')}`.toLowerCase();
    return text.includes(query.toLowerCase()) && (!liveOnly || session.live) &&
      (!activeTags.length || activeTags.every((tag) => session.tags.includes(tag)));
  }), [sessions, query, liveOnly, activeTags]);
  const filterCount = activeTags.length + Number(liveOnly);

  useEffect(() => {
    if (!active) {
      dialogRef.current?.close(); setDialog(null); setTagOpen(false); setMenuFor(null);
      return;
    }
    function handleKeys(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === 'Escape') {
        setTagOpen(false);
        setMenuFor(null);
      }
    }
    window.addEventListener('keydown', handleKeys);
    return () => window.removeEventListener('keydown', handleKeys);
  }, [active]);

  function announce(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(''), 3200);
  }
  function showDialog(name: DialogName) {
    setFormError('');
    setDialog(name);
    requestAnimationFrame(() => {
      if (name && dialogRef.current && !dialogRef.current.open) dialogRef.current.showModal();
    });
  }
  function closeDialog() {
    if (dialogRef.current?.open) dialogRef.current.close();
    setDialog(null);
  }
  function toggleTag(tag: string) {
    setActiveTags((current) => current.includes(tag) ? current.filter((item) => item !== tag) : [...current, tag]);
  }
  function createSession(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!newTitle.trim() || !newCourse.trim() || !newPlace.trim() || !newDate || !newTime) {
      setFormError('Fill in each field to add your sample session.'); return;
    }
    const session: Session = {
      id: `local-${Date.now()}`, title: newTitle.trim(), course: newCourse.trim().toUpperCase(),
      place: newPlace.trim(), when: newDate, start: newTime, people: 1, max: Math.min(8, Math.max(2, Number(newMax) || 4)),
      tags: [newTag], host: 'You', initials: 'YO', live: true, tint: 'sage',
      note: 'A local sample session created in this preview. Details clear when the page refreshes.',
    };
    setSessions((current) => [session, ...current]);
    setSelectedId(session.id); setActiveTags([]); setQuery(''); setLiveOnly(false);
    setNewTitle(''); setNewCourse(''); setNewPlace(''); setNewDate(''); setNewTime('');
    closeDialog(); setMobileTab('details'); announce('Sample session added locally. It is not published.');
  }
  function toggleAttach(session: Session) {
    if (attached.includes(session.id)) {
      setAttached((current) => current.filter((id) => id !== session.id));
      setSessions((current) => current.map((item) => item.id === session.id ? { ...item, people: Math.max(1, item.people - 1) } : item));
      announce('You left this sample session.');
    } else if (session.people < session.max) {
      setAttached((current) => [...current, session.id]);
      setSessions((current) => current.map((item) => item.id === session.id ? { ...item, people: Math.min(item.max, item.people + 1) } : item));
      announce('You joined this sample session locally.');
    } else announce('This sample session is full. No one was added.');
  }
  function sendDraft(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!draft.trim() || !selectedConversation) return;
    setLocalMessages((current) => ({ ...current, [selectedConversation]: [...(current[selectedConversation] ?? []), { name: 'You', text: draft.trim(), time: 'Now', mine: true }] }));
    setDraft(''); announce('Draft added to this local sample thread. Nothing was sent.');
  }
  function hideConversation(conversation: Conversation) {
    setConversations((current) => current.filter((item) => item.id !== conversation.id));
    setHiddenConversation(conversation); setMenuFor(null);
    if (selectedConversation === conversation.id) setSelectedConversation(conversations.find((item) => item.id !== conversation.id)?.id ?? '');
    announce('Conversation hidden locally. Undo is available.');
  }
  function undoHide() {
    if (!hiddenConversation) return;
    setConversations((current) => [hiddenConversation, ...current]);
    setSelectedConversation(hiddenConversation.id); setHiddenConversation(null); setToast('');
  }
  function submitReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    closeDialog(); setReportReason('');
    announce('Preview only — no report was submitted or sent.');
  }

  return (
    <section className="community-app" aria-label="Community" data-testid="community-page">
      <header className="community-topbar">
        <a className="community-brand" href={`${import.meta.env.BASE_URL}whiteboard`} onClick={(event) => { event.preventDefault(); onHome(); }} aria-label="Norse Whiteboard home">
          <span className="brand-symbol"><BookOpen size={17} /></span><span>Norse <b>Whiteboard</b></span>
        </a>
        <div className="community-context"><span className="context-mark">COMMUNITY</span><span className="context-course">Find your study people</span></div>
        <button type="button" className="top-profile" onClick={onProfile} aria-label="Open profile and settings"><span className="profile-initials">YO</span><span className="profile-name">Your preview</span><ChevronDown size={14} /></button>
      </header>
      <div className="community-notice" role="note"><span className="notice-dot" /><b>Sample sessions · local preview</b><span>Nothing is sent, reported, saved, or connected to an account.</span></div>

      <div className="community-mobile-tabs" role="tablist" aria-label="Community panels">
        <button role="tab" aria-selected={mobileTab === 'messages'} onClick={() => setMobileTab('messages')}><MessageCircle size={15} />Messages</button>
        <button role="tab" aria-selected={mobileTab === 'sessions'} onClick={() => setMobileTab('sessions')}><Users size={15} />Sessions</button>
        <button role="tab" aria-selected={mobileTab === 'details'} onClick={() => setMobileTab('details')}><CircleHelp size={15} />Details</button>
      </div>

      <div className="community-layout">
        <aside className={`messages-panel ${mobileTab === 'messages' ? 'mobile-active' : ''}`} aria-label="Messages">
          <div className="panel-heading"><div><span className="panel-eyebrow">YOUR STUDY TABLE</span><h2>Messages <span className="message-count">{conversations.length}</span></h2></div><button className="icon-button" aria-label="New message preview" title="Messages are sample-only" onClick={() => announce('Messaging is a local preview only.')}><Plus size={17} /></button></div>
          <div className="conversation-list">
            {conversations.length ? conversations.map((conversation) => (
              <article className={`conversation ${conversation.id === selectedConversation ? 'selected' : ''}`} key={conversation.id}>
                <button className="conversation-select" onClick={() => { setSelectedConversation(conversation.id); setMenuFor(null); }} aria-pressed={conversation.id === selectedConversation}>
                  <span className={`avatar avatar-${conversation.initials.toLowerCase()}`}>{conversation.initials}</span>
                  <span className="conversation-copy"><strong>{conversation.name}</strong><small>{conversation.course}</small><span className="conversation-preview">{conversation.preview}</span></span>
                  <span className="conversation-time">{conversation.time}{conversation.unread && <i>{conversation.unread}</i>}</span>
                </button>
                <button className="conversation-menu-trigger" aria-label={`Options for ${conversation.name}`} aria-expanded={menuFor === conversation.id} onClick={() => setMenuFor(menuFor === conversation.id ? null : conversation.id)}><MoreHorizontal size={17} /></button>
                {menuFor === conversation.id && <div className="conversation-menu" role="menu">
                  <button role="menuitem" onClick={() => { setReportTarget(conversation); setReportReason(''); showDialog('report'); setMenuFor(null); }}><Flag size={14} />Report preview</button>
                  <button role="menuitem" onClick={() => hideConversation(conversation)}><X size={14} />Block / hide locally</button>
                </div>}
              </article>
            )) : <div className="conversation-empty"><MessageCircle size={23} /><b>No conversations here</b><span>Hidden conversations can be restored with Undo.</span>{hiddenConversation && <button onClick={undoHide}>Undo hide</button>}</div>}
          </div>
          {activeConversation && <section className="thread-box" aria-label={`Sample thread with ${activeConversation.name}`}>
            <div className="thread-heading"><span className="online-mark" /><span>Sample thread with <b>{activeConversation.name.split(' ')[0]}</b></span><span className="thread-lock">LOCAL</span></div>
            <div className="thread-messages" aria-live="polite">
              {thread.map((message, index) => <div className={`thread-message ${message.mine ? 'mine' : ''}`} key={`${message.time}-${index}`}><span className="thread-name">{message.name} · {message.time}</span><p>{message.text}</p></div>)}
            </div>
            <form className="message-compose" onSubmit={sendDraft}>
              <label className="sr-only" htmlFor="local-message">Write a local sample message</label>
              <input id="local-message" value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="Write a local draft…" maxLength={240} />
              <button type="submit" aria-label="Add draft to sample thread" disabled={!draft.trim()}><Send size={15} /></button>
            </form>
            <p className="thread-disclaimer">Drafts stay on this page and clear on refresh.</p>
          </section>}
        </aside>

        <section className={`sessions-panel ${mobileTab === 'sessions' ? 'mobile-active' : ''}`} aria-labelledby="find-people">
          <div className="sessions-heading">
            <div className="heading-copy"><span className="panel-eyebrow">A PLACE TO FIGURE IT OUT TOGETHER</span><h1 id="find-people">Find Your People<span className="heading-period">.</span></h1><p>Good company makes the hard parts easier.</p></div>
            <button className="create-button" onClick={() => showDialog('create')}><Plus size={16} />Create</button>
          </div>
          <div className="session-tools">
            <div className="filter-controls">
              <div className="tag-filter-wrap">
                <button className={`tag-filter ${activeTags.length ? 'is-active' : ''}`} aria-expanded={tagOpen} aria-haspopup="true" onClick={() => setTagOpen(!tagOpen)}><Filter size={14} />Tags{activeTags.length > 0 && <span className="filter-badge">{activeTags.length}</span>}<ChevronDown size={13} /></button>
                {tagOpen && <div className="tag-popover" role="group" aria-label="Filter by tags">
                  <div className="popover-heading"><b>Study tags</b><button onClick={() => setTagOpen(false)} aria-label="Close tags"><X size={15} /></button></div>
                  <div className="tag-options">{allTags.map((tag) => <button className={`tag-option ${activeTags.includes(tag) ? 'chosen' : ''}`} key={tag} aria-pressed={activeTags.includes(tag)} onClick={() => toggleTag(tag)}>{activeTags.includes(tag) ? <Check size={13} /> : <span className="empty-check" />}{tag}</button>)}</div>
                  {activeTags.length > 0 && <button className="clear-tags" onClick={() => setActiveTags([])}>Clear tags</button>}
                </div>}
              </div>
              <button className={`live-filter ${liveOnly ? 'is-active' : ''}`} aria-pressed={liveOnly} onClick={() => setLiveOnly(!liveOnly)}><span className="live-pulse" />Live now</button>
              {filterCount > 0 && <button className="reset-filters" onClick={() => { setActiveTags([]); setLiveOnly(false); setQuery(''); }}>Reset <span>{filterCount}</span></button>}
            </div>
            <label className="session-search"><Search size={16} /><span className="sr-only">Search study sessions</span><input ref={searchRef} value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search courses, topics, places…" /><kbd>⌘ K</kbd></label>
          </div>
          <div className="session-count"><span>{filtered.length} {filtered.length === 1 ? 'session' : 'sessions'} to explore</span><span className="scroll-hint">A few good places to start <ArrowUpRight size={13} /></span></div>
          {filtered.length ? <div className="session-grid" aria-live="polite">
            {filtered.map((session, index) => <button className={`session-card tint-${session.tint} ${selectedId === session.id ? 'is-selected' : ''}`} key={session.id} onClick={() => { setSelectedId(session.id); if (window.innerWidth < 720) setMobileTab('details'); }} aria-pressed={selectedId === session.id} style={{ animationDelay: `${index * 45}ms` }}>
              <span className="card-art" aria-hidden="true"><span className="art-index">NW / {String(index + 1).padStart(2, '0')}</span><span className="art-graphic"><i /><i /><i /></span><span className="art-label">{session.course}</span></span>
              <span className="card-content"><span className="card-topline"><span className="course-tag">{session.course}</span>{session.live ? <span className="card-live"><i />Live</span> : <span className="card-upcoming">Soon</span>}</span>
                <strong className="session-title">{session.title}</strong><span className="host-line"><span className="host-avatar">{session.initials}</span>Hosted by {session.host}</span>
                <span className="session-card-bottom"><span className="capacity">{session.people}/{session.max} spots</span><span className="card-when"><Clock3 size={12} />{session.when}, {session.start}</span></span>
              </span>
              <span className="card-pin" aria-label="Pinned sample session"><BookOpen size={10} aria-hidden="true" /></span>
            </button>)}
          </div> : <div className="sessions-empty"><span className="empty-sketch"><Search size={21} /></span><h3>No sessions on this page</h3><p>Try a different search or remove a tag to see more study tables.</p><button onClick={() => { setActiveTags([]); setLiveOnly(false); setQuery(''); }}>Reset all filters</button></div>}
          <div className="grid-footnote"><span>Showing sample sessions around campus</span><span>Just browsing is welcome <span className="footnote-star">✦</span></span></div>
        </section>

        <aside className={`details-panel ${mobileTab === 'details' ? 'mobile-active' : ''}`} aria-label="Selected session details">
          {selected ? <><div className="details-topline"><span className="panel-eyebrow">SESSION NOTES</span><button className="details-close mobile-only" onClick={() => setMobileTab('sessions')} aria-label="Back to sessions"><X size={17} /></button></div>
            <div className={`detail-art tint-${selected.tint}`}><span className="detail-art-label">A study table for</span><span className="detail-art-course">{selected.course}</span><span className="detail-art-orbit orbit-a" /><span className="detail-art-orbit orbit-b" /><BookOpen className="detail-book" size={32} /></div>
            <div className="details-main"><div className="detail-tags">{selected.tags.map((tag) => <span className="topic-tag" key={tag}>{tag}</span>)}</div><h2>{selected.title}</h2><p className="detail-description">{selected.note}</p>
              <div className="detail-facts">
                <div className="detail-fact"><span className="fact-icon"><BookOpen size={15} /></span><span><small>COURSE</small><b>{selected.course}</b></span></div>
                <div className="detail-fact"><span className="fact-icon"><MapPin size={15} /></span><span><small>WHERE</small><b>{selected.place}</b></span></div>
                <div className="detail-fact"><span className="fact-icon"><CalendarDays size={15} /></span><span><small>WHEN</small><b>{selected.when} · {selected.start}</b></span></div>
              </div>
              <div className="detail-host"><span className="host-avatar large">{selected.initials}</span><span><small>SESSION HOST</small><b>{selected.host}</b></span><span className={`detail-status ${selected.live ? 'is-live' : ''}`}>{selected.live && <i />}{selected.live ? 'Live now' : 'Upcoming'}</span></div>
              <div className="capacity-block"><div className="capacity-heading"><span>Seats at the table</span><b>{selected.people} <i>/</i> {selected.max}</b></div><div className="capacity-track"><span style={{ width: `${Math.min(100, (selected.people / selected.max) * 100)}%` }} /></div><small>{selected.max - selected.people > 0 ? `${selected.max - selected.people} ${selected.max - selected.people === 1 ? 'spot' : 'spots'} left` : 'This table is full'}</small></div>
              <button className={`attach-button ${attached.includes(selected.id) ? 'attached' : ''}`} onClick={() => toggleAttach(selected)} disabled={!attached.includes(selected.id) && selected.people >= selected.max}>{attached.includes(selected.id) ? <><Check size={16} />Attached · Leave table</> : selected.people >= selected.max ? 'Table is full' : <><Plus size={16} />Attach to this table</>}</button>
              <p className="attach-disclaimer">Preview action only. No one is notified.</p>
              <div className="detail-footer"><span>LOCAL SAMPLE</span><span>Refresh to start over</span></div>
            </div>
          </> : <div className="sessions-empty">Choose a session to see its details.</div>}
        </aside>
      </div>

      <dialog className="community-dialog" ref={dialogRef} aria-labelledby={dialog === 'create' ? 'create-session-title' : 'report-title'} onCancel={(event) => { event.preventDefault(); closeDialog(); }} onClick={(event) => { if (event.target === event.currentTarget) closeDialog(); }}>
        <button className="dialog-x" type="button" onClick={closeDialog} aria-label="Close dialog"><X size={18} /></button>
        {dialog === 'create' ? <form onSubmit={createSession} className="dialog-form">
          <span className="panel-eyebrow">ADD A STUDY TABLE</span><h2 id="create-session-title">Make room for one more.</h2><p>This creates a local sample card only. It won’t be published to campus.</p>
          <label>Topic or session title<input value={newTitle} onChange={(event) => setNewTitle(event.target.value)} placeholder="e.g. Review chapter 5 together" maxLength={68} autoFocus /></label>
          <div className="form-row"><label>Course<input value={newCourse} onChange={(event) => setNewCourse(event.target.value)} placeholder="MATH 221" maxLength={20} /></label><label>Tag<select value={newTag} onChange={(event) => setNewTag(event.target.value)}>{allTags.map((tag) => <option key={tag}>{tag}</option>)}</select></label></div>
          <label>Where<input value={newPlace} onChange={(event) => setNewPlace(event.target.value)} placeholder="Library · 2nd floor" maxLength={45} /></label>
          <div className="form-row"><label>When<input type="text" value={newDate} onChange={(event) => setNewDate(event.target.value)} placeholder="Today / Thursday" maxLength={24} /></label><label>Start time<input type="time" value={newTime} onChange={(event) => setNewTime(event.target.value)} /></label></div>
          <label>Maximum people<select value={newMax} onChange={(event) => setNewMax(event.target.value)}>{[2, 3, 4, 5, 6, 8].map((n) => <option key={n} value={n}>{n} people</option>)}</select></label>
          {formError && <p className="form-error" role="alert">{formError}</p>}
          <button className="dialog-submit" type="submit"><Plus size={16} />Add sample session</button>
        </form> : dialog === 'report' ? <form onSubmit={submitReport} className="dialog-form">
          <span className="panel-eyebrow">STUDENT SAFETY</span><h2 id="report-title">Report preview</h2><p>You’re previewing a report for <b>{reportTarget?.name}</b>. No report is submitted, stored, or sent anywhere.</p>
          <label>What would you like to flag?<select required value={reportReason} onChange={(event) => setReportReason(event.target.value)}><option value="">Choose a reason</option><option>Inappropriate message</option><option>Unkind or harmful behavior</option><option>Something else</option></select></label>
          <label>Optional note<textarea placeholder="Local preview only — don’t include personal information." rows={3} maxLength={180} /></label>
          <div className="report-note"><Flag size={15} /><span>This preview does not contact a moderator or create a real report.</span></div>
          <button className="dialog-submit" type="submit" disabled={!reportReason}>Close preview</button>
        </form> : null}
      </dialog>
      {toast && <div className="community-toast" role="status" aria-live="polite">{toast}{hiddenConversation && toast.includes('hidden') && <button onClick={undoHide}>Undo</button>}</div>}
      <button className="help-fab" aria-label="Preview information" onClick={() => announce('This is a local-only design preview. Refresh clears all changes.')}><CircleHelp size={17} /></button>
    </section>
  );
}