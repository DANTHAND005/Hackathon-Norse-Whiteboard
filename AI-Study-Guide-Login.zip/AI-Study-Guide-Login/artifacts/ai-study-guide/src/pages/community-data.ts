export type Session = {
  id: string; title: string; course: string; place: string; when: string;
  start: string; people: number; max: number; tags: string[]; host: string;
  initials: string; live: boolean; pinned?: boolean; tint: string; note: string;
};

export const seedSessions: Session[] = [
  { id: 'calc', title: 'Derivatives, minus the panic', course: 'MATH 221', place: 'Library · 2nd floor', when: 'Today', start: '2:30 PM', people: 3, max: 5, tags: ['Calculus', 'Exam prep'], host: 'Maya Chen', initials: 'MC', live: true, pinned: true, tint: 'sage', note: 'Working through the practice set together. Bring one problem you got stuck on.' },
  { id: 'bio', title: 'Cell biology study circle', course: 'BIOL 212', place: 'Miller Hall · 104', when: 'Today', start: '3:00 PM', people: 2, max: 4, tags: ['Biology', 'Study group'], host: 'Eli Johnson', initials: 'EJ', live: true, pinned: true, tint: 'peach', note: 'A quiet, collaborative review of cell signaling and this week’s lecture notes.' },
  { id: 'econ', title: 'Microeconomics: problem set 4', course: 'ECON 201', place: 'Student Union · nook 3', when: 'Today', start: '4:15 PM', people: 4, max: 6, tags: ['Economics', 'Homework'], host: 'Noah Williams', initials: 'NW', live: false, pinned: true, tint: 'blue', note: 'Compare approaches to the elasticity questions before Friday’s deadline.' },
  { id: 'writing', title: 'A little accountability hour', course: 'ENG 102', place: 'Library · quiet room', when: 'Tomorrow', start: '10:00 AM', people: 1, max: 3, tags: ['Writing', 'Focus time'], host: 'Riley Park', initials: 'RP', live: false, pinned: true, tint: 'lilac', note: 'Bring your own work. We’ll start with a small goal and check in at the end.' },
  { id: 'stats', title: 'Stats lab: distributions', course: 'STAT 250', place: 'Science Center · 218', when: 'Today', start: '5:00 PM', people: 2, max: 4, tags: ['Statistics', 'Study group'], host: 'Amara Singh', initials: 'AS', live: true, pinned: true, tint: 'yellow', note: 'Reviewing normal distributions and getting ready for the lab quiz.' },
  { id: 'history', title: 'History readings, together', course: 'HIST 130', place: 'Café North · back table', when: 'Thursday', start: '1:00 PM', people: 2, max: 5, tags: ['History', 'Focus time'], host: 'Theo Martin', initials: 'TM', live: false, pinned: true, tint: 'rose', note: 'A low-key reading session with a few breaks to share interesting passages.' },
];

export const allTags = ['Calculus', 'Biology', 'Economics', 'Writing', 'Statistics', 'History', 'Exam prep', 'Study group', 'Homework', 'Focus time'];
export type Conversation = { id: string; name: string; course: string; preview: string; time: string; initials: string; unread?: number };
export const initialConversations: Conversation[] = [
  { id: 'sarah', name: 'Sarah Miller', course: 'MATH 221', preview: 'Do you want to compare notes before…', time: '2m', initials: 'SM', unread: 2 },
  { id: 'jordan', name: 'Jordan Lee', course: 'BIOL 212', preview: 'I found a helpful diagram for chapter 6', time: '18m', initials: 'JL' },
  { id: 'study-pals', name: 'Econ study pals', course: 'ECON 201 · 3 people', preview: 'Noah: see you at the union!', time: '1h', initials: 'EP' },
];
export const threadSamples: Record<string, { name: string; text: string; time: string; mine?: boolean }[]> = {
  sarah: [{ name: 'Sarah', text: 'Hey! Are you reviewing derivatives today?', time: '1:42 PM' }, { name: 'You', text: 'Yes, I’m working through the practice set now.', time: '1:44 PM', mine: true }, { name: 'Sarah', text: 'Do you want to compare notes before the quiz?', time: '1:46 PM' }],
  jordan: [{ name: 'Jordan', text: 'I found a helpful diagram for chapter 6.', time: '1:28 PM' }, { name: 'You', text: 'That would be great, thank you!', time: '1:31 PM', mine: true }],
  'study-pals': [{ name: 'Noah', text: 'I can bring the elasticity worksheet.', time: '12:10 PM' }, { name: 'You', text: 'Perfect — see you there.', time: '12:14 PM', mine: true }],
};

