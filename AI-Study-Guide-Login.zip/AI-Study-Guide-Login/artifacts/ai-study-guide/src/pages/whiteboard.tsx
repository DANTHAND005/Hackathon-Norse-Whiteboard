import { type ChangeEvent, type FormEvent, useEffect, useRef, useState } from 'react';
import { Link, useLocation } from 'wouter';
import {
  ArrowLeft, ArrowRight, Copy, Hand, Info, Monitor,
  MousePointer2, Sparkles, Upload, Users, UserRound, X,
} from 'lucide-react';
import { convertToExcalidrawElements, Excalidraw, restoreElements } from '@excalidraw/excalidraw';
import type { ExcalidrawImperativeAPI } from '@excalidraw/excalidraw/types';
import '@excalidraw/excalidraw/index.css';
import './whiteboard.css';
import ChatSummary from './chat-summary';
import VoiceSessions from '../voice/VoiceSessions';

type Prompt = { id: string; person: string; page: number; question: string; answer: string };
type BoardSection = 'whiteboard' | 'community' | 'profile';
type DialogMode = 'share' | 'ai' | null;

const prompts: Prompt[] = [
  {
    id: 'jake-observer', person: 'JAKE · circled on p.2', page: 2,
    question: 'Why not just call update()?',
    answer: 'You could, but then the subject has to know every class that cares about it. notify() loops over a list instead, so new observers plug in without touching the subject. I sketched it below.',
  },
  {
    id: 'aaron-subject', person: 'AARON · p.2', page: 2,
    question: 'Subject vs Observer, which one holds the list?',
    answer: 'The Subject keeps the observer list. Observers subscribe or unsubscribe; when its state changes, the Subject notifies each one.',
  },
  {
    id: 'daniel-missed', person: 'DANIEL · p.1', page: 1,
    question: 'Explain this page like I missed the lecture',
    answer: 'This sample page introduces the Observer pattern: one object broadcasts a change to several interested listeners.',
  },
  {
    id: 'daniel-quiz', person: 'DANIEL · p.1', page: 1,
    question: 'Quiz me on the 3 patterns',
    answer: 'Sample prompt: Which pattern lets observers subscribe to updates from a subject? Answer: Observer.',
  },
];

const pageNotes: Record<number, { title: string; body: string; equation: string }> = {
  1: {
    title: 'Three patterns, one idea',
    body: 'Design patterns are reusable ways to describe a solution. Today: Observer, Strategy, and Factory.',
    equation: 'Pattern → shared vocabulary',
  },
  2: {
    title: 'Observer Pattern',
    body: 'A subject keeps a list of observers and notifies them automatically when its state changes.',
    equation: 'Subject → attach(), detach(), notify()',
  },
  3: {
    title: 'Strategy Pattern',
    body: 'Encapsulate a family of algorithms so the strategy can change without changing its client.',
    equation: 'Context → strategy.execute()',
  },
  4: {
    title: 'Factory Pattern',
    body: 'Create objects through a shared interface while keeping construction details in one place.',
    equation: 'Creator → createProduct()',
  },
  5: {
    title: 'Quick review',
    body: 'Pick the pattern that makes the change you need easier to explain, test, and maintain.',
    equation: 'Observe · Swap · Create',
  },
};

type SceneElements = ReturnType<typeof convertToExcalidrawElements>;

function createPageScene(page: number, note: (typeof pageNotes)[number]) {
  const mainNode = page === 3 ? 'Context' : page === 4 ? 'Creator' : page === 5 ? 'Review' : 'Subject';
  const firstNode = page === 3 ? 'Strategy A' : page === 4 ? 'Product A' : 'Observer A';
  const secondNode = page === 3 ? 'Strategy B' : page === 4 ? 'Product B' : 'Observer B';

  return restoreElements(convertToExcalidrawElements([
    {
      type: 'text', x: 100, y: 70,
      text: `LECTURE 7 · PAGE ${page} · SAMPLE NOTES`,
      fontSize: 16, fontFamily: 2, strokeColor: '#777777',
    },
    { type: 'text', x: 100, y: 112, text: note.title, fontSize: 30, fontFamily: 2, strokeColor: '#171717' },
    { type: 'text', x: 100, y: 165, text: note.body.replace(/(.{1,62})(?:\s|$)/g, '$1\n').trim(), fontSize: 19, fontFamily: 2, strokeColor: '#555555' },
    {
      type: 'rectangle', x: 100, y: 285, width: 190, height: 88,
      strokeColor: '#171717', backgroundColor: '#ffffff', fillStyle: 'solid',
      label: { text: mainNode, fontSize: 19, fontFamily: 2, strokeColor: '#171717' },
    },
    { type: 'text', x: 330, y: 314, text: 'notifies →', fontSize: 18, fontFamily: 2, strokeColor: '#171717' },
    {
      type: 'rectangle', x: 500, y: 250, width: 210, height: 74,
      strokeColor: '#171717', backgroundColor: '#ffffff', fillStyle: 'solid',
      label: { text: firstNode, fontSize: 18, fontFamily: 2, strokeColor: '#171717' },
    },
    {
      type: 'rectangle', x: 500, y: 365, width: 210, height: 74,
      strokeColor: '#171717', backgroundColor: '#ffffff', fillStyle: 'solid',
      label: { text: secondNode, fontSize: 18, fontFamily: 2, strokeColor: '#171717' },
    },
    {
      type: 'rectangle', x: 100, y: 490, width: 610, height: 65,
      strokeColor: '#d2aa00', backgroundColor: '#fff3b0', fillStyle: 'solid',
      label: { text: note.equation, fontSize: 17, fontFamily: 2, strokeColor: '#282828' },
    },
  ]), null, { repairBindings: true });
}

function createPageScenes(): Record<number, SceneElements> {
  const scenes: Record<number, SceneElements> = {};
  for (const [pageNumber, note] of Object.entries(pageNotes)) {
    const page = Number(pageNumber);
    scenes[page] = createPageScene(page, note);
  }
  return scenes;
}

export default function Whiteboard() {
  const [, setLocation] = useLocation();
  const [pageScenes] = useState<Record<number, SceneElements>>(createPageScenes);
  const pageScenesRef = useRef(pageScenes);
  const currentPageRef = useRef(2);
  const [excalidrawAPI, setExcalidrawAPI] = useState<ExcalidrawImperativeAPI | null>(null);
  const [activeColor, setActiveColor] = useState('#171717');
  const [selectedPrompt, setSelectedPrompt] = useState(prompts[0]);
  const [page, setPage] = useState(2);
  const [activeSection, setActiveSection] = useState<BoardSection>('whiteboard');
  const [summaryExpanded, setSummaryExpanded] = useState(() => window.innerWidth > 800);
  const [inputMode, setInputMode] = useState<'mouse' | 'touch'>(
    () => window.matchMedia('(pointer: coarse)').matches ? 'touch' : 'mouse',
  );
  const [canvasEngaged, setCanvasEngaged] = useState(false);
  const canvasEngagedRef = useRef(false);
  const canvasHostRef = useRef<HTMLDivElement>(null);
  const [toast, setToast] = useState('');
  const [question, setQuestion] = useState('');
  const [localQuestion, setLocalQuestion] = useState('');
  const [dialogMode, setDialogMode] = useState<DialogMode>(null);
  const [dialogQuestion, setDialogQuestion] = useState('');
  const dialogRef = useRef<HTMLDialogElement>(null);
  const shareInputRef = useRef<HTMLInputElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (dialogMode && dialog && !dialog.open) dialog.showModal();
    if (!dialogMode && dialog?.open) dialog.close();
  }, [dialogMode]);

  useEffect(() => {
    function releaseCanvas(event: PointerEvent) {
      if (!canvasHostRef.current?.contains(event.target as Node)) setCanvasInteraction(false);
    }
    function releaseOnBlur() { setCanvasInteraction(false); }
    document.addEventListener('pointerdown', releaseCanvas, true);
    window.addEventListener('blur', releaseOnBlur);
    return () => {
      document.removeEventListener('pointerdown', releaseCanvas, true);
      window.removeEventListener('blur', releaseOnBlur);
    };
  }, []);

  useEffect(() => {
    const host = canvasHostRef.current;
    if (!host) return;
    function handleTrackpad(event: WheelEvent) {
      // Only gate Excalidraw's native (non-passive) wheel listener. Inactive
      // hover must reach the browser's default page scroll, not the editor.
      if (!canvasEngagedRef.current) {
        event.stopPropagation();
      }
      // Engaged gestures must reach the native handler: it translates both
      // axes, handles Shift/pinch zoom, and cancels in-flight viewport animations.
      // updateScene only sets app state and does not cancel those animations.
    }
    host.addEventListener('wheel', handleTrackpad, { capture: true, passive: false });
    return () => host.removeEventListener('wheel', handleTrackpad, true);
  }, [excalidrawAPI, activeSection]);

  function setCanvasInteraction(engaged: boolean) {
    canvasEngagedRef.current = engaged;
    setCanvasEngaged(engaged);
  }

  useEffect(() => {
    if (!excalidrawAPI) return;
    // Excalidraw publishes its API before it finishes applying initialData.
    const timer = setTimeout(() => {
      excalidrawAPI.scrollToContent(pageScenesRef.current[currentPageRef.current], {
        fitToViewport: true, viewportZoomFactor: .8,
      });
    }, 150);
    return () => clearTimeout(timer);
  }, [excalidrawAPI]);

  function announce(message: string) {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(''), 4200);
  }

  function selectPage(nextPage: number, updatePrompt = true) {
    const bounded = Math.max(1, Math.min(5, nextPage));
    if (bounded === currentPageRef.current) return;
    if (excalidrawAPI) {
      pageScenesRef.current[currentPageRef.current] = [
        ...excalidrawAPI.getSceneElements(),
      ] as SceneElements;
    }
    currentPageRef.current = bounded;
    setPage(bounded);
    excalidrawAPI?.updateScene({
      elements: restoreElements(pageScenesRef.current[bounded], null, { repairBindings: true }),
    });
    excalidrawAPI?.scrollToContent(pageScenesRef.current[bounded], { fitToContent: true });
    if (updatePrompt) {
      const matched = prompts.find((prompt) => prompt.page === bounded);
      if (matched) setSelectedPrompt(matched);
    }
  }

  function submitQuestion(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!question.trim()) {
      announce('Type a sample question first. Nothing has been sent or saved.');
      return;
    }
    setLocalQuestion(question.trim());
    setQuestion('');
    announce('Added as a local draft for this session. Nothing was sent or saved.');
  }

  function submitAIDraft(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!dialogQuestion.trim()) {
      announce('Type a question first. AI is not connected in this preview.');
      return;
    }
    setLocalQuestion(dialogQuestion.trim());
    setDialogQuestion('');
    setDialogMode(null);
    announce('Added as a local draft for this session. AI is not connected; nothing was sent.');
  }

  function changeInkColor(event: ChangeEvent<HTMLInputElement>) {
    const color = event.currentTarget.value;
    setActiveColor(color);
    excalidrawAPI?.updateScene({ appState: { currentItemStrokeColor: color } });
  }

  function insertImage() {
    if (!excalidrawAPI) {
      announce('The drawing canvas is still loading. Try again in a moment.');
      return;
    }
    excalidrawAPI.setActiveTool({ type: 'image', insertOnCanvasDirectly: true });
  }

  function toggleInputMode() {
    if (!excalidrawAPI) return;
    const next = excalidrawAPI?.getAppState().activeTool.type === 'hand' ? 'mouse' : 'touch';
    setInputMode(next);
    // setActiveTool is batched. Reading and reapplying activeTool immediately
    // afterward would overwrite the new tool with the previous one.
    excalidrawAPI.setActiveTool({ type: next === 'mouse' ? 'selection' : 'hand' });
    announce(next === 'touch'
      ? 'Hand mode: drag to pan. Click the hand again to return to mouse selection.'
      : 'Mouse mode: click to select and edit. Click outside the canvas to scroll the page.');
  }

  async function copyPreviewLink() {
    const link = window.location.href;
    try {
      await navigator.clipboard.writeText(link);
      announce('Preview link copied. Board edits are not included in the link.');
    } catch {
      shareInputRef.current?.focus();
      shareInputRef.current?.select();
      announce('Copy is unavailable here. Select the preview link to copy it; board edits are not included.');
    }
  }

  const summarySidebar = (
    <ChatSummary expanded={summaryExpanded} onToggle={() => setSummaryExpanded(!summaryExpanded)}
      prompts={prompts} selectedId={selectedPrompt.id}
      onSelect={(prompt) => {
        setSelectedPrompt(prompt);
        selectPage(prompt.page, false);
        setActiveSection('whiteboard');
      }}
      localQuestion={localQuestion} onDiscard={() => setLocalQuestion('')}
      question={question} onQuestionChange={setQuestion} onSubmit={submitQuestion} />
  );

  return (
    <main className="board-page">
      <header className="board-topbar">
        <Link className="board-brand" href="/" aria-label="Back to Norse Whiteboard sign in" data-testid="link-board-home">
          <img src={`${import.meta.env.BASE_URL}norse-whiteboard-logo.jpeg`} alt="" />
          <span>Norse Whiteboard</span>
        </Link>
        <div className="board-heading">
          <h1>Whiteboard</h1>
          <p>ASE 420 · Midterm review <span aria-hidden="true">/</span> Sample board</p>
        </div>
        <div className="board-actions">
          <button className="board-button" type="button" onClick={() => setDialogMode('share')} data-testid="button-share">
            Share
          </button>
          <button className="board-button primary" type="button" onClick={() => setDialogMode('ai')} data-testid="button-ask-ai">
            <Sparkles size={14} /> Ask AI
          </button>
        </div>
      </header>

      <div className="preview-alert" role="note" data-testid="status-preview-notice">
        <Info size={15} aria-hidden="true" />
        <div>
          <strong>Preview mode — local sample board.</strong>{' '}
          <span>Drawings stay local and clear on refresh; AI and cloud sync aren’t connected. Live study audio is real-time, but it does not sync drawings.</span>
        </div>
      </div>

      <section className="board-workspace" aria-label="Sample whiteboard workspace">
        {activeSection === 'whiteboard' ? (
          <>
            <div className="toolbar" aria-label="Board actions">
              <span className="board-file-label" data-testid="text-board-file">Lecture 7 · Sample board · page {page} of 5</span>
              <div className="toolbar-spacer" />
              <label className="ink-picker" htmlFor="board-ink-color">
                <span>Ink</span>
                <input id="board-ink-color" type="color" value={activeColor} onChange={changeInkColor} aria-label="Choose any ink color" data-testid="input-ink-color" />
              </label>
              <button className="board-button yellow" type="button" onClick={insertImage} data-testid="button-upload">
                <Upload size={14} /> Add image
              </button>
            </div>

            <div className={`board-layout ${summaryExpanded ? '' : 'is-summary-collapsed'}`}>
              {summarySidebar}

              <section className="board-canvas-wrap" aria-label={`Interactive sample board, page ${page} of 5`}>
                <div ref={canvasHostRef} className="excalidraw-host" data-input-mode={inputMode}
                  data-canvas-engaged={canvasEngaged}
                  onPointerDownCapture={(event) => {
                    if (event.target instanceof HTMLCanvasElement) setCanvasInteraction(true);
                  }}
                  onKeyDownCapture={(event) => {
                    if (event.key === 'Escape') setCanvasInteraction(false);
                  }}
                  data-testid="panel-board-canvas">
                  <Excalidraw
                    initialData={{
                      elements: pageScenesRef.current[page],
                      appState: {
                        currentItemStrokeColor: activeColor,
                        viewBackgroundColor: '#ffffff',
                        activeTool: { type: inputMode === 'touch' ? 'hand' : 'selection', locked: inputMode === 'touch', customType: null, lastActiveTool: null },
                      },
                      scrollToContent: true,
                    }}
                    excalidrawAPI={setExcalidrawAPI}
                    theme="light"
                    handleKeyboardGlobally={false}
                    name={`Norse Whiteboard page ${page}`}
                    UIOptions={{ canvasActions: { saveToActiveFile: false } }}
                    onChange={(elements) => {
                      pageScenesRef.current[currentPageRef.current] = [...elements] as SceneElements;
                    }}
                    renderTopRightUI={(isMobile, appState) => (
                      <button className={`input-mode-toggle ${isMobile ? 'is-compact' : ''}`} type="button"
                        onClick={toggleInputMode}
                        aria-label={`Switch to ${appState.activeTool.type === 'hand' ? 'mouse selection' : 'hand panning'}`}
                        title={`Switch to ${appState.activeTool.type === 'hand' ? 'mouse selection' : 'hand panning'}`}
                        data-testid="button-input-mode">
                        {appState.activeTool.type === 'hand' ? <Hand size={17} /> : <MousePointer2 size={17} />}
                        {!isMobile && (
                          <span>{appState.activeTool.type === 'hand' ? 'Hand' : 'Mouse'}</span>
                        )}
                      </button>
                    )}
                  />
                </div>
                <div className="board-page-count">
                  <div className="page-stepper" aria-label="Change sample page">
                    <button type="button" aria-label="Previous page" onClick={() => selectPage(page - 1)} data-testid="button-previous-page"><ArrowLeft size={15} /></button>
                    <span>{page} / 5</span>
                    <button type="button" aria-label="Next page" onClick={() => selectPage(page + 1)} data-testid="button-next-page"><ArrowRight size={15} /></button>
                  </div>
                </div>
              </section>
            </div>
          </>
        ) : activeSection === 'community' ? (
          <div className={`board-layout ${summaryExpanded ? '' : 'is-summary-collapsed'}`}>
          {summarySidebar}
          <section className="destination-panel" aria-labelledby="community-heading">
            <div className="destination-heading">
              <span className="destination-icon"><Users size={20} /></span>
              <div>
                <h2 id="community-heading">Community preview</h2>
                <p>Choose a sample discussion to open its page on the board.</p>
              </div>
            </div>
            <div className="community-list">
              {prompts.map((prompt) => (
                <button
                  className="community-item"
                  key={prompt.id}
                  type="button"
                  onClick={() => {
                    setSelectedPrompt(prompt);
                    selectPage(prompt.page, false);
                    setActiveSection('whiteboard');
                  }}
                  data-testid={`button-community-${prompt.id}`}
                >
                  <span className="history-meta">{prompt.person}</span>
                  <strong>{prompt.question}</strong>
                  <small>Open page {prompt.page} on the whiteboard <ArrowRight size={13} /></small>
                </button>
              ))}
            </div>
          </section>
          </div>
        ) : (
          <section className="destination-panel profile-preview" aria-labelledby="profile-heading">
            <div className="destination-heading">
              <span className="destination-icon"><UserRound size={20} /></span>
              <div>
                <h2 id="profile-heading">Profile & settings preview</h2>
                <p>No account is signed in. This preview has no profile data or saved preferences.</p>
              </div>
            </div>
            <div className="profile-preview-card">
              <span>Account status</span>
              <strong>Preview only</strong>
              <p>Your drawings and settings remain in this tab and clear when the page is refreshed.</p>
              <div className="profile-actions">
                <button className="board-button primary" type="button" onClick={() => setActiveSection('whiteboard')} data-testid="button-profile-back">
                  Return to Whiteboard
                </button>
                <button className="board-button" type="button" onClick={() => setLocation('/')} data-testid="button-profile-signin">
                  Back to sign-in preview
                </button>
              </div>
            </div>
          </section>
        )}
      </section>

      <nav className="board-footer" aria-label="Main navigation">
        <button className={`board-nav ${activeSection === 'whiteboard' ? 'active' : ''}`} type="button" aria-current={activeSection === 'whiteboard' ? 'page' : undefined} onClick={() => setActiveSection('whiteboard')} data-testid="nav-whiteboard">
          <Monitor size={17} /> Whiteboard
        </button>
        <button className={`board-nav ${activeSection === 'community' ? 'active' : ''}`} type="button" aria-current={activeSection === 'community' ? 'page' : undefined} onClick={() => setActiveSection('community')} data-testid="nav-community">
          <Users size={17} /> Community
        </button>
        <button className={`board-nav ${activeSection === 'profile' ? 'active' : ''}`} type="button" aria-current={activeSection === 'profile' ? 'page' : undefined} onClick={() => setActiveSection('profile')} data-testid="nav-profile">
          <UserRound size={17} /> Profile / Settings
        </button>
      </nav>

      <dialog
        ref={dialogRef}
        className="board-dialog"
        aria-labelledby={dialogMode === 'share' ? 'share-dialog-title' : 'ai-dialog-title'}
        onCancel={(event) => {
          event.preventDefault();
          setDialogMode(null);
        }}
        onClick={(event) => {
          if (event.target === event.currentTarget) setDialogMode(null);
        }}
      >
        <button className="dialog-close" type="button" onClick={() => setDialogMode(null)} aria-label="Close dialog" data-testid="button-close-dialog">
          <X size={17} />
        </button>
        {dialogMode === 'share' ? (
          <div className="dialog-content">
            <h2 id="share-dialog-title">Share this preview</h2>
            <p>This copies the page address only. Your drawings are not included or uploaded.</p>
            <label htmlFor="preview-link">Preview link</label>
            <input ref={shareInputRef} id="preview-link" value={window.location.href} readOnly onFocus={(event) => event.currentTarget.select()} data-testid="input-preview-link" />
            <button className="board-button primary" type="button" onClick={copyPreviewLink} data-testid="button-copy-preview-link">
              <Copy size={14} /> Copy preview link
            </button>
          </div>
        ) : dialogMode === 'ai' ? (
          <form className="dialog-content" onSubmit={submitAIDraft} data-testid="form-ai-draft">
            <h2 id="ai-dialog-title">Ask AI</h2>
            <p>AI is not connected in this preview. Add a local draft below; nothing will be sent.</p>
            <label htmlFor="ai-draft-question">Your question</label>
            <textarea id="ai-draft-question" value={dialogQuestion} onChange={(event) => setDialogQuestion(event.target.value)} placeholder="Ask about the sample board..." rows={4} data-testid="input-ai-draft" />
            <button className="board-button primary" type="submit" data-testid="button-save-ai-draft">
              Add local draft
            </button>
          </form>
        ) : null}
      </dialog>

      {toast && <div className="board-toast" role="status" aria-live="polite" data-testid="status-board-feedback">{toast}</div>}
      <VoiceSessions />
    </main>
  );
}