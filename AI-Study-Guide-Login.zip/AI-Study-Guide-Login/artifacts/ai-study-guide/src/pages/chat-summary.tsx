import type { FormEvent } from 'react';
import { ChevronLeft, ChevronRight, Send } from 'lucide-react';

export type SummaryPrompt = {
  id: string; person: string; page: number; question: string; answer: string;
};

type Props = {
  expanded: boolean;
  onToggle: () => void;
  prompts: SummaryPrompt[];
  selectedId: string;
  onSelect: (prompt: SummaryPrompt) => void;
  localQuestion: string;
  onDiscard: () => void;
  question: string;
  onQuestionChange: (value: string) => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
};

export default function ChatSummary(props: Props) {
  return (
    <aside className={`history-panel ${props.expanded ? '' : 'is-collapsed'}`} aria-label="Chat Summary">
      <button className="history-collapse" type="button" aria-expanded={props.expanded}
        aria-controls="chat-summary-content" onClick={props.onToggle}
        data-testid="button-toggle-chat-summary">
        {props.expanded ? <>
          <strong>Chat Summary</strong><span>{props.prompts.length} samples</span><ChevronLeft size={15} />
        </> : <>
          <ChevronRight size={15} /><strong className="collapsed-summary-label">Chat Summary</strong>
        </>}
      </button>
      {props.expanded && (
        <div id="chat-summary-content" className="history-content">
          <div className="history-list">
            {props.prompts.map((prompt) => (
              <button className="history-item" type="button" key={prompt.id}
                aria-pressed={props.selectedId === prompt.id} onClick={() => props.onSelect(prompt)}
                data-testid={`button-chat-${prompt.id}`}>
                <span className="history-meta">{prompt.person}</span>
                <strong>{prompt.question}</strong><small>{prompt.answer}</small>
              </button>
            ))}
          </div>
          {props.localQuestion && (
            <div className="local-question-draft" data-testid="card-local-question-draft">
              <span>Local draft · this session only</span><p>{props.localQuestion}</p>
              <button type="button" onClick={props.onDiscard} data-testid="button-discard-draft">Discard draft</button>
            </div>
          )}
          <form className="chat-box" onSubmit={props.onSubmit} data-testid="form-board-question">
            <label htmlFor="board-question">Ask about the board</label>
            <div className="chat-entry">
              <input id="board-question" value={props.question}
                onChange={(event) => props.onQuestionChange(event.target.value)}
                placeholder="Type a question..." data-testid="input-board-question" />
              <button type="submit" aria-label="Add local question draft" data-testid="button-submit-question"><Send size={14} /></button>
            </div>
          </form>
        </div>
      )}
    </aside>
  );
}