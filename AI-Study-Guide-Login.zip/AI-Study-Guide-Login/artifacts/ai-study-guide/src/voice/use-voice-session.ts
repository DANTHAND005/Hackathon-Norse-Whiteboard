import { useEffect, useRef, useState } from 'react';
import {
  createVoiceRoom, joinVoiceRoom, pollVoiceRoom, signalVoiceRoom,
  leaveVoiceRoom, endVoiceRoom, setBaseUrl,
  type VoiceMembership, type VoiceRoom,
} from '@workspace/api-client-react';
import { PeerAudio } from './peer-audio';
import { RoomConnection, retryable, terminalRoomError } from './room-connection';
import type { PeerStatus, VoiceSessionState } from './types';

setBaseUrl(import.meta.env.BASE_URL.replace(/\/$/, ''));

function explain(error: unknown) {
  const data = (error as { data?: { error?: string } })?.data;
  if (data?.error) return data.error;
  return error instanceof Error ? error.message : 'The audio session could not connect. Try again.';
}
function credentials(session: VoiceMembership) {
  return { headers: { Authorization: `Bearer ${session.token}` }, credentials: 'same-origin' as const };
}
function roomFrom(value: string) {
  try { return new URL(value).searchParams.get('voice') ?? ''; }
  catch { return value.trim(); }
}

export function useVoiceSession(): VoiceSessionState {
  const [room, setRoom] = useState<VoiceRoom | null>(null);
  const [participantId, setParticipantId] = useState<string | null>(null);
  const [status, setStatus] = useState<VoiceSessionState['status']>('idle');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [micEnabled, setMicEnabled] = useState(false);
  const [micBusy, setMicBusy] = useState(false);
  const [audioBlocked, setAudioBlocked] = useState(false);
  const [peers, setPeers] = useState<Record<string, PeerStatus>>({});
  const [musicName, setMusicName] = useState<string | null>(null);
  const [musicPlaying, setMusicPlaying] = useState(false);
  const [voiceVolume, setVoiceVolumeState] = useState(1);
  const [musicVolume, setMusicVolumeState] = useState(.35);
  const session = useRef<VoiceMembership | null>(null);
  const engine = useRef<PeerAudio | null>(null);
  const connection = useRef<RoomConnection | null>(null);
  const outageSince = useRef<number | null>(null);
  const micOperation = useRef(false);
  const mic = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cursor = useRef(0);
  const occupied = useRef(false);
  const disposed = useRef(false);
  const volumes = useRef({ voice: 1, music: .35 });

  function releaseAudio() {
    connection.current?.close();
    connection.current = null;
    outageSince.current = null;
    micOperation.current = false;
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    mic.current?.getTracks().forEach((track) => track.stop());
    mic.current = null;
    engine.current?.close();
    engine.current = null;
    session.current = null;
    cursor.current = 0;
  }
  function reset() {
    releaseAudio();
    setRoom(null); setParticipantId(null); setStatus('idle'); setPeers({});
    setMicEnabled(false); setMicBusy(false); setAudioBlocked(false);
    setMusicName(null); setMusicPlaying(false);
  }
  useEffect(() => {
    disposed.current = false;
    function notifyLeave() {
      const current = session.current;
      if (current) void leaveVoiceRoom(current.room.id, { ...credentials(current), keepalive: true }).catch(() => {});
      releaseAudio();
    }
    window.addEventListener('pagehide', notifyLeave);
    return () => {
      disposed.current = true;
      window.removeEventListener('pagehide', notifyLeave);
      notifyLeave();
    };
  }, []);

  async function poll(current: VoiceMembership) {
    if (session.current !== current) return;
    try {
      const response = await connection.current!.run(
        (options) => pollVoiceRoom(current.room.id, { after: cursor.current }, options),
        () => {
          if (session.current !== current) return;
          outageSince.current ??= Date.now();
          setStatus('reconnecting');
        },
      );
      if (session.current !== current) return;
      outageSince.current = null;
      setStatus('connected');
      setRoom({
        ...response.room,
        music: current.room.hostId === current.participantId ? current.room.music : response.room.music,
        participants: response.room.participants.map((person) => person.id === current.participantId
          ? { ...person, micEnabled: Boolean(mic.current) } : person),
      });
      const ids = new Set(response.room.participants.map((person) => person.id));
      setPeers((previous) => Object.fromEntries(Object.entries(previous).filter(([id]) => ids.has(id))));
      engine.current?.sync(response.room.participants);
      for (const event of response.events) {
        if (session.current !== current) return;
        await engine.current?.handle(event);
      }
      cursor.current = response.cursor;
      timer.current = setTimeout(() => void poll(current), 1000);
    } catch (failure) {
      if (session.current !== current) return;
      outageSince.current ??= Date.now();
      if (retryable(failure) && Date.now() - outageSince.current < 90_000) {
        setStatus('reconnecting');
        timer.current = setTimeout(() => void poll(current), 4000);
        return;
      }
      reset();
      setError(`Audio disconnected: ${retryable(failure)
        ? 'The room server stayed unreachable after repeated retries. Start or join a room again.'
        : explain(failure)}`);
    }
  }

  async function enter(create: boolean, name: string, displayName: string) {
    if (occupied.current || session.current) return;
    setError(null);
    if (!displayName.trim()) { setError('Enter your display name.'); return; }
    if (!window.isSecureContext || !navigator.mediaDevices || !window.RTCPeerConnection || !window.AudioContext) {
      setError('Voice sessions need HTTPS and a browser that supports WebRTC audio.'); return;
    }
    occupied.current = true; setBusy(true); setStatus('joining');
    let membership: VoiceMembership | null = null;
    try {
      membership = create
        ? await createVoiceRoom({ name: name.trim(), displayName: displayName.trim() })
        : await joinVoiceRoom(roomFrom(name), { displayName: displayName.trim() });
      if (disposed.current) {
        await leaveVoiceRoom(membership.room.id, credentials(membership));
        return;
      }
      const current = membership;
      session.current = current;
      cursor.current = 0;
      connection.current = new RoomConnection(current.room.id, current.token, (failure) => {
        if (session.current !== current) return;
        if (terminalRoomError(failure)) {
          reset(); setError(`Audio disconnected: ${explain(failure)}`);
        } else {
          setError('Audio controls changed locally, but room status has not synced yet. Retrying automatically.');
        }
      }, () => {
        if (session.current === current) setError((previous) =>
          previous?.startsWith('Audio controls changed locally') ? null : previous);
      });
      const transport = connection.current;
      engine.current = new PeerAudio(current.participantId, current.room.hostId === current.participantId, {
        send: (id, kind, data) => transport.run((options) =>
          signalVoiceRoom(current.room.id, { recipientId: id, kind, data }, options)),
        status: (id, state) => {
          if (session.current === current) setPeers((previous) => ({ ...previous, [id]: state }));
        },
        blocked: () => { if (session.current === current) setAudioBlocked(true); },
        error: (message) => { if (session.current === current) setError(message); },
        recovered: (name) => {
          if (session.current === current) setError((previous) =>
            previous?.startsWith(`Could not connect audio to ${name}.`) ? null : previous);
        },
        musicStopped: () => {
          if (session.current !== current) return;
          setMusicPlaying(false);
          current.room.music = { title: current.room.music.title, playing: false };
          transport.update({ music: current.room.music });
        },
      });
      engine.current.setVolumes(volumes.current.voice, volumes.current.music);
      setRoom(current.room); setParticipantId(current.participantId); setStatus('connected');
      void poll(current);
    } catch (failure) {
      if (membership) void leaveVoiceRoom(membership.room.id, credentials(membership)).catch(() => {});
      reset(); setError(explain(failure));
    } finally { occupied.current = false; if (!disposed.current) setBusy(false); }
  }

  async function depart(end: boolean) {
    const current = session.current;
    if (!current || occupied.current) return;
    occupied.current = true; setBusy(true); setError(null);
    // Stop all microphone and music tracks immediately, even if the server is offline.
    reset();
    try {
      await (end ? endVoiceRoom : leaveVoiceRoom)(current.room.id, {
        ...credentials(current), signal: AbortSignal.timeout(8000),
      });
    } catch (failure) {
      if ((failure as { status?: number })?.status !== 404) {
        setError(`Audio stopped locally. ${explain(failure)} Idle memberships expire automatically.`);
      }
    } finally { occupied.current = false; setBusy(false); }
  }

  async function toggleMic() {
    const current = session.current;
    if (!current || micOperation.current) return;
    micOperation.current = true;
    setMicBusy(true); setError(null);
    try {
      if (mic.current) {
        mic.current.getTracks().forEach((track) => track.stop());
        mic.current = null; setMicEnabled(false);
        await engine.current?.setMicrophone(null);
        if (session.current !== current) return;
        connection.current?.update({ micEnabled: false });
      } else {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false,
        });
        if (session.current !== current) { stream.getTracks().forEach((track) => track.stop()); return; }
        mic.current = stream;
        await engine.current?.setMicrophone(stream.getAudioTracks()[0]);
        if (session.current !== current) { stream.getTracks().forEach((track) => track.stop()); return; }
        setMicEnabled(true);
        connection.current?.update({ micEnabled: true });
        stream.getAudioTracks()[0].onended = () => {
          if (session.current !== current) return;
          mic.current = null; setMicEnabled(false);
          void engine.current?.setMicrophone(null);
          connection.current?.update({ micEnabled: false });
          setError('Microphone access ended. Enable it again to speak.');
        };
      }
    } catch (failure) {
      if (session.current !== current) return;
      mic.current?.getTracks().forEach((track) => track.stop());
      mic.current = null; setMicEnabled(false);
      await engine.current?.setMicrophone(null).catch(() => {});
      connection.current?.update({ micEnabled: false });
      const name = (failure as DOMException)?.name;
      const policyDocument = document as Document & {
        permissionsPolicy?: { allowsFeature(feature: string): boolean };
        featurePolicy?: { allowsFeature(feature: string): boolean };
      };
      const policy = policyDocument.permissionsPolicy ?? policyDocument.featurePolicy;
      const blockedInPreview = policy?.allowsFeature('microphone') === false;
      setError(name === 'NotAllowedError'
        ? blockedInPreview
          ? 'This embedded preview blocks microphone access. Open the app preview in a separate browser tab, start a fresh room, and allow microphone access there.'
          : 'Microphone permission was denied. You can still listen, or allow microphone access in browser settings.'
        : name === 'NotFoundError' ? 'No microphone was found. You can still listen.' : explain(failure));
    } finally {
      if (session.current === current) { micOperation.current = false; setMicBusy(false); }
    }
  }

  async function loadMusic(file: File) {
    const current = session.current;
    if (!current || current.room.hostId !== current.participantId) return;
    if (file.size > 50 * 1024 * 1024 || !(
      file.type.startsWith('audio/') || /\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(file.name))) {
      setError('Choose an audio file smaller than 50 MB. MP3 and WAV are recommended.'); return;
    }
    setError(null);
    try {
      engine.current?.loadMusic(file);
      const title = file.name.slice(0, 180);
      setMusicName(title); setMusicPlaying(false);
      current.room.music = { title, playing: false };
      connection.current?.update({ music: current.room.music });
    } catch (failure) { setError(explain(failure)); }
  }

  async function toggleMusic() {
    const current = session.current;
    if (!current || current.room.hostId !== current.participantId || !musicName) return;
    setError(null);
    try {
      const playing = !musicPlaying;
      if (playing) await engine.current?.playMusic();
      else engine.current?.pauseMusic();
      if (session.current !== current) return;
      current.room.music = { title: musicName, playing };
      setMusicPlaying(playing);
      connection.current?.update({ music: current.room.music });
    } catch (failure) { engine.current?.pauseMusic(); setMusicPlaying(false); setError(explain(failure)); }
  }
  function volume(voice: number, music: number) {
    volumes.current = { voice: Math.max(0, Math.min(1, voice)), music: Math.max(0, Math.min(1, music)) };
    setVoiceVolumeState(volumes.current.voice); setMusicVolumeState(volumes.current.music);
    engine.current?.setVolumes(volumes.current.voice, volumes.current.music);
  }
  async function enableSound() {
    try { await engine.current?.enableSound(); setAudioBlocked(false); }
    catch { setError('The browser blocked audio playback. Click Enable sound again or allow audio for this site.'); }
  }

  return {
    room, participantId, status, busy, error, micEnabled, micBusy, audioBlocked, peers,
    isHost: !!room && room.hostId === participantId,
    inviteRoomId: new URLSearchParams(window.location.search).get('voice') ?? '',
    musicName, musicPlaying, voiceVolume, musicVolume,
    createRoom: (name, displayName) => enter(true, name, displayName),
    joinRoom: (id, displayName) => enter(false, id, displayName),
    leaveRoom: () => depart(false), endRoom: () => depart(true), toggleMic,
    loadMusic, toggleMusic, setVoiceVolume: (value) => volume(value, volumes.current.music),
    setMusicVolume: (value) => volume(volumes.current.voice, value), enableSound,
    clearError: () => setError(null),
  };
}