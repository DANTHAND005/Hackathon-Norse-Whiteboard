import type { VoiceRoom } from '@workspace/api-client-react';

export type PeerStatus = 'connecting' | 'connected' | 'reconnecting' | 'failed';

export interface VoiceSessionState {
  room: VoiceRoom | null;
  participantId: string | null;
  status: 'idle' | 'joining' | 'connected' | 'reconnecting';
  busy: boolean;
  error: string | null;
  micEnabled: boolean;
  micBusy: boolean;
  audioBlocked: boolean;
  isHost: boolean;
  inviteRoomId: string;
  peers: Record<string, PeerStatus>;
  musicName: string | null;
  musicPlaying: boolean;
  voiceVolume: number;
  musicVolume: number;
  createRoom(name: string, displayName: string): Promise<void>;
  joinRoom(roomId: string, displayName: string): Promise<void>;
  leaveRoom(): Promise<void>;
  endRoom(): Promise<void>;
  toggleMic(): Promise<void>;
  loadMusic(file: File): Promise<void>;
  toggleMusic(): Promise<void>;
  setVoiceVolume(value: number): void;
  setMusicVolume(value: number): void;
  enableSound(): Promise<void>;
  clearError(): void;
}