import { updateVoiceState } from '@workspace/api-client-react';

type StatePatch = Parameters<typeof updateVoiceState>[1];

export function retryable(error: unknown) {
  const status = (error as { status?: number })?.status;
  return status === 408 || status === 429 || (status !== undefined && status >= 500) ||
    error instanceof TypeError || (error as Error)?.name === 'AbortError';
}

export function terminalRoomError(error: unknown) {
  return [400, 401, 403, 404, 409, 415].includes((error as { status?: number })?.status ?? 0);
}

function wait(ms: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(new DOMException('Session stopped', 'AbortError')); return; }
    const abort = () => {
      clearTimeout(timer);
      signal.removeEventListener('abort', abort);
      reject(new DOMException('Session stopped', 'AbortError'));
    };
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', abort);
      resolve();
    }, ms);
    signal.addEventListener('abort', abort, { once: true });
  });
}

/** Session-scoped requests: cancellable retries and serialized, coalesced state. */
export class RoomConnection {
  private controller = new AbortController();
  private pending: StatePatch | null = null;
  private updating = false;
  private stateTimer?: ReturnType<typeof setTimeout>;

  constructor(
    private roomId: string,
    private token: string,
    private stateFailed: (error: unknown) => void,
    private stateRestored: () => void,
  ) {}

  get closed() { return this.controller.signal.aborted; }

  async run<T>(operation: (options: RequestInit) => Promise<T>, reconnecting?: () => void): Promise<T> {
    for (let attempt = 0; ; attempt++) {
      if (this.closed) throw new DOMException('Session stopped', 'AbortError');
      const request = new AbortController();
      const abort = () => request.abort();
      this.controller.signal.addEventListener('abort', abort, { once: true });
      const timeout = setTimeout(abort, 8000);
      let failure: unknown;
      try {
        const result = await operation({
          headers: { Authorization: `Bearer ${this.token}` },
          credentials: 'same-origin', signal: request.signal,
        });
        if (this.closed) throw new DOMException('Session stopped', 'AbortError');
        return result;
      } catch (error) {
        failure = error;
      } finally {
        clearTimeout(timeout);
        this.controller.signal.removeEventListener('abort', abort);
      }
      if (this.closed || !retryable(failure)) throw failure;
      reconnecting?.();
      if (attempt >= 2) throw failure;
      await wait(1000 * 2 ** attempt, this.controller.signal);
    }
  }

  update(patch: StatePatch) {
    if (this.closed) return;
    this.pending = { ...this.pending, ...patch };
    if (!this.updating && !this.stateTimer) void this.flush();
  }

  private restore(patch: StatePatch) {
    this.pending = { ...patch, ...this.pending };
  }

  private async flush() {
    if (this.closed || this.updating) return;
    this.updating = true;
    try {
      while (this.pending && !this.closed) {
        const patch = this.pending;
        this.pending = null;
        try {
          await this.run((options) => updateVoiceState(this.roomId, patch, options));
          if (!this.closed) this.stateRestored();
        } catch (error) {
          if (this.closed) return;
          this.stateFailed(error);
          if (terminalRoomError(error) || !retryable(error) || this.closed) return;
          // New local changes supersede an older failed update.
          this.restore(patch);
          this.stateTimer = setTimeout(() => {
            this.stateTimer = undefined;
            void this.flush();
          }, 4000);
          return;
        }
      }
    } finally { this.updating = false; }
  }

  close() {
    this.controller.abort();
    clearTimeout(this.stateTimer);
    this.pending = null;
  }
}