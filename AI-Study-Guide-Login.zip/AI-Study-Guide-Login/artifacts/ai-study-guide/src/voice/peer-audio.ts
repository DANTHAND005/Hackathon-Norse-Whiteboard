import type { VoiceEvent, VoiceParticipant } from '@workspace/api-client-react';
import type { PeerStatus } from './types';

type Peer = {
  pc: RTCPeerConnection; remote: VoiceParticipant; caller: boolean;
  candidates: RTCIceCandidateInit[]; makingOffer: boolean;
  audio: HTMLAudioElement[]; timer?: ReturnType<typeof setTimeout>;
  outbound: Promise<void>; generation: number; descriptionPending: boolean;
  localCandidates: RTCIceCandidateInit[]; offerId: string | null;
  remoteOfferId: string | null; seenOffers: Set<string>;
  recoveryAttempts: number; recoveryTimer?: ReturnType<typeof setTimeout>;
};
type Callbacks = {
  send(id: string, kind: VoiceEvent['kind'], data: string): Promise<void>;
  status(id: string, state: PeerStatus): void;
  blocked(): void;
  error(message: string): void;
  musicStopped(): void;
  recovered(name: string): void;
};

const offerMarker = /^a=x-norse-offer-id:([\w-]+)\r?$/m;
function withOfferId(sdp: string, id: string | null) {
  return id ? `${sdp.trimEnd()}\r\na=x-norse-offer-id:${id}\r\n` : sdp;
}
function withoutOfferId(sdp: string) {
  return sdp.replace(/^a=x-norse-offer-id:[\w-]+\r?\n?/gm, '');
}
function matchesIce(candidate: RTCIceCandidateInit, description: RTCSessionDescription | null) {
  if (!description) return false;
  return !candidate.usernameFragment ||
    [...description.sdp.matchAll(/^a=ice-ufrag:(.+)\r?$/gm)]
      .some((match) => match[1].trim() === candidate.usernameFragment);
}

export class PeerAudio {
  private peers = new Map<string, Peer>();
  private mic: MediaStreamTrack | null = null;
  private context: AudioContext | null = null;
  private destination: MediaStreamAudioDestinationNode | null = null;
  private gain: GainNode | null = null;
  private musicElement: HTMLAudioElement | null = null;
  private musicUrl: string | null = null;
  private closed = false;
  private voiceVolume = 1;
  private musicVolume = .35;

  constructor(private id: string, private isHost: boolean, private callbacks: Callbacks) {
    if (isHost) {
      this.context = new AudioContext();
      this.destination = this.context.createMediaStreamDestination();
      this.gain = this.context.createGain();
      this.gain.gain.value = this.musicVolume;
      this.musicElement = new Audio();
      const source = this.context.createMediaElementSource(this.musicElement);
      source.connect(this.destination); // Broadcast independent of host's listening volume.
      source.connect(this.gain).connect(this.context.destination);
      this.musicElement.onended = () => callbacks.musicStopped();
      this.musicElement.onerror = () => {
        callbacks.error('This audio file could not be played. Try an MP3 or WAV file.');
        callbacks.musicStopped();
      };
    }
  }

  sync(participants: VoiceParticipant[]) {
    const ids = new Set(participants.map((p) => p.id));
    for (const [id, peer] of this.peers) {
      if (!ids.has(id)) { this.disposePeer(peer); this.peers.delete(id); }
    }
    for (const person of participants) {
      if (person.id !== this.id && !this.peers.has(person.id)) this.createPeer(person);
    }
  }

  private createPeer(remote: VoiceParticipant) {
    const pc = new RTCPeerConnection({
      // Public STUN discovers direct routes. No TURN relay or vendor API key.
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
    });
    const peer: Peer = {
      pc, remote, caller: this.id < remote.id, candidates: [],
      makingOffer: false, audio: [],
      outbound: Promise.resolve(), generation: 0, descriptionPending: false,
      localCandidates: [], offerId: null, remoteOfferId: null, seenOffers: new Set(),
      recoveryAttempts: 0,
    };
    this.peers.set(remote.id, peer);
    this.callbacks.status(remote.id, 'connecting');
    pc.onicecandidate = (event) => {
      if (event.candidate && !this.closed && pc.signalingState !== 'closed') {
        const candidate = event.candidate.toJSON();
        if (!matchesIce(candidate, pc.localDescription)) return;
        if (peer.descriptionPending) peer.localCandidates.push(candidate);
        else void this.sendInOrder(peer, 'candidate', JSON.stringify(candidate)).catch(() => {});
      }
    };
    pc.ontrack = (event) => {
      if (peer.audio.some((element) => (element.srcObject as MediaStream | null)
        ?.getTracks().includes(event.track))) return;
      const slot = pc.getTransceivers().indexOf(event.transceiver);
      const element = new Audio();
      element.autoplay = true;
      element.dataset.voicePeer = remote.id;
      element.dataset.voiceSource = slot === 1 ? 'music' : 'microphone';
      element.srcObject = new MediaStream([event.track]);
      element.volume = slot === 1 ? this.musicVolume : this.voiceVolume;
      peer.audio.push(element);
      // Rendering explicitly owns both mic and music tracks, with separate volume.
      element.style.display = 'none';
      document.body.append(element);
      void element.play().catch(() => this.callbacks.blocked());
    };
    pc.onconnectionstatechange = () => {
      if (this.closed || pc.connectionState === 'closed') return;
      if (pc.connectionState === 'connected') {
        this.connected(peer);
      } else if (pc.connectionState === 'failed') this.recover(peer);
      else if (pc.connectionState === 'disconnected') {
        this.callbacks.status(remote.id, 'reconnecting');
        clearTimeout(peer.timer);
        // Allow a short network handoff to recover without renegotiation.
        peer.timer = setTimeout(() => this.recover(peer), 4000);
      }
    };
    peer.timer = setTimeout(() => {
      if (pc.connectionState !== 'connected') this.recover(peer);
    }, 30_000);
    // One designated offerer avoids glare. Callees use the offered transceivers
    // rather than adding duplicate m-lines before accepting an offer.
    if (peer.caller) {
      pc.addTransceiver('audio', { direction: 'sendrecv' });
      pc.addTransceiver('audio', {
        direction: this.isHost ? 'sendonly' : remote.isHost ? 'recvonly' : 'inactive',
      });
      void this.prepareTracks(peer).then(() => this.offer(peer)).catch(() => this.recover(peer));
    }
  }

  private async prepareTracks(peer: Peer) {
    const [voice, music] = peer.pc.getTransceivers();
    if (!voice || !music) throw new Error('Audio channel negotiation failed.');
    voice.direction = 'sendrecv';
    music.direction = this.isHost ? 'sendonly' : peer.remote.isHost ? 'recvonly' : 'inactive';
    await voice.sender.replaceTrack(this.mic);
    await music.sender.replaceTrack(this.isHost ? this.destination!.stream.getAudioTracks()[0] : null);
  }

  private async offer(peer: Peer, restart = false) {
    if (this.closed || peer.makingOffer || peer.pc.signalingState === 'closed') return;
    if (peer.pc.signalingState !== 'stable' && !(restart && peer.pc.signalingState === 'have-local-offer')) return;
    peer.makingOffer = true;
    peer.descriptionPending = true;
    peer.localCandidates = [];
    const generation = ++peer.generation;
    peer.offerId = crypto.randomUUID();
    try {
      if (peer.pc.signalingState === 'have-local-offer') {
        await peer.pc.setLocalDescription({ type: 'rollback' });
      }
      await peer.pc.setLocalDescription(await peer.pc.createOffer({ iceRestart: restart }));
      await this.sendDescription(peer, 'offer', peer.pc.localDescription!.sdp, peer.offerId);
      if (peer.pc.connectionState === 'connected') this.connected(peer);
    } catch {
      if (generation === peer.generation) {
        peer.generation++;
        peer.localCandidates = [];
      }
      if (!this.closed) this.recover(peer);
    } finally { peer.descriptionPending = false; peer.makingOffer = false; }
  }

  private sendInOrder(peer: Peer, kind: VoiceEvent['kind'], data: string) {
    const generation = peer.generation;
    const sending = peer.outbound.then(async () => {
      if (this.closed || !this.peers.has(peer.remote.id) ||
        peer.pc.signalingState === 'closed' || generation !== peer.generation) return;
      await this.callbacks.send(peer.remote.id, kind, data);
    });
    peer.outbound = sending.catch(() => {
      if (!this.closed && generation === peer.generation) {
        if (kind === 'offer' || kind === 'answer') {
          peer.generation++;
          peer.localCandidates = [];
        }
        this.recover(peer);
      }
    });
    return sending;
  }

  private sendDescription(peer: Peer, kind: 'offer' | 'answer', sdp: string, id: string | null) {
    const sending = this.sendInOrder(peer, kind, withOfferId(sdp, id));
    peer.descriptionPending = false;
    for (const candidate of peer.localCandidates.splice(0)) {
      void this.sendInOrder(peer, 'candidate', JSON.stringify(candidate)).catch(() => {});
    }
    return sending;
  }

  private async drainCandidates(peer: Peer) {
    const waiting = peer.candidates.splice(0);
    for (const candidate of waiting) {
      if (matchesIce(candidate, peer.pc.remoteDescription)) await peer.pc.addIceCandidate(candidate);
      else peer.candidates.push(candidate);
    }
    // Retain a small bounded buffer for candidates arriving before a restart SDP.
    peer.candidates = peer.candidates.slice(-64);
  }

  async handle(event: VoiceEvent) {
    const peer = this.peers.get(event.senderId);
    if (!peer || this.closed) return; // A departed participant's queued signal.
    try {
      if (event.kind === 'candidate') {
        const candidate: RTCIceCandidateInit = JSON.parse(event.data);
        if (matchesIce(candidate, peer.pc.remoteDescription)) await peer.pc.addIceCandidate(candidate);
        else peer.candidates.push(candidate);
        peer.candidates = peer.candidates.slice(-64);
        return;
      }
      const id = event.data.match(offerMarker)?.[1] ?? null;
      const sdp = withoutOfferId(event.data);
      if (event.kind === 'offer') {
        if (peer.caller) return;
        if (id && peer.seenOffers.has(id)) {
          if (id === peer.remoteOfferId && peer.pc.localDescription?.type === 'answer') {
            void this.sendDescription(peer, 'answer', peer.pc.localDescription.sdp, id).catch(() => {});
          }
          return;
        }
        peer.descriptionPending = true;
        peer.localCandidates = [];
        peer.generation++;
        await peer.pc.setRemoteDescription({ type: 'offer', sdp });
        await this.prepareTracks(peer);
        await peer.pc.setLocalDescription(await peer.pc.createAnswer());
        peer.remoteOfferId = id;
        if (id) {
          peer.seenOffers.add(id);
          if (peer.seenOffers.size > 12) peer.seenOffers.delete(peer.seenOffers.values().next().value!);
        }
        // Do not hold up room heartbeats while signaling requests retry.
        void this.sendDescription(peer, 'answer', peer.pc.localDescription!.sdp, id).catch(() => {});
      } else {
        // A retried request can deliver an answer from an earlier ICE attempt.
        if (id && id !== peer.offerId) return;
        if (peer.pc.signalingState !== 'have-local-offer') return;
        await peer.pc.setRemoteDescription({ type: 'answer', sdp });
      }
      await this.drainCandidates(peer);
    } catch {
      peer.descriptionPending = false;
      if (!this.closed) this.recover(peer);
    }
  }

  private connected(peer: Peer) {
    if (this.closed || !this.peers.has(peer.remote.id)) return;
    clearTimeout(peer.timer);
    clearTimeout(peer.recoveryTimer);
    peer.recoveryTimer = undefined;
    peer.recoveryAttempts = 0;
    this.callbacks.status(peer.remote.id, 'connected');
    this.callbacks.recovered(peer.remote.name);
  }

  private recover(peer: Peer) {
    if (this.closed || !this.peers.has(peer.remote.id) || peer.pc.signalingState === 'closed') return;
    if (peer.pc.connectionState === 'connected') { this.connected(peer); return; }
    if (peer.recoveryTimer) return;
    clearTimeout(peer.timer);
    this.callbacks.status(peer.remote.id, 'reconnecting');
    if (!peer.caller) {
      // Only the designated caller offers; both ends detect lost ICE connectivity.
      peer.recoveryTimer = setTimeout(() => {
        peer.recoveryTimer = undefined;
        if (peer.pc.connectionState !== 'connected') this.fail(peer);
        else this.connected(peer);
      }, 95_000);
      return;
    }
    if (peer.recoveryAttempts >= 3) { this.fail(peer); return; }
    peer.recoveryTimer = setTimeout(() => {
      peer.recoveryTimer = undefined;
      if (this.closed) return;
      if (peer.pc.connectionState === 'connected') { this.connected(peer); return; }
      if (peer.makingOffer) { this.recover(peer); return; }
      peer.recoveryAttempts++;
      void this.offer(peer, true);
      peer.timer = setTimeout(() => this.recover(peer), 20_000);
    }, 1000 * 2 ** peer.recoveryAttempts);
  }

  private fail(peer: Peer) {
    clearTimeout(peer.timer);
    clearTimeout(peer.recoveryTimer);
    peer.recoveryTimer = undefined;
    if (!this.closed && this.peers.has(peer.remote.id)) {
      this.callbacks.status(peer.remote.id, 'failed');
      this.callbacks.error(`Could not connect audio to ${peer.remote.name}. Automatic retries did not restore it. Try another network; this network may require a relay. Leave and rejoin to retry.`);
    }
  }

  async setMicrophone(track: MediaStreamTrack | null) {
    this.mic = track;
    await Promise.all([...this.peers.values()].map(async ({ pc }) => {
      const sender = pc.getTransceivers()[0]?.sender;
      if (sender && pc.signalingState !== 'closed') await sender.replaceTrack(track);
    }));
  }

  loadMusic(file: File) {
    if (!this.musicElement) throw new Error('Only the host can stream music.');
    this.musicElement.pause();
    if (this.musicUrl) URL.revokeObjectURL(this.musicUrl);
    this.musicUrl = URL.createObjectURL(file);
    this.musicElement.src = this.musicUrl;
    this.musicElement.load();
  }
  async playMusic() {
    await this.context?.resume();
    await this.musicElement?.play();
  }
  pauseMusic() { this.musicElement?.pause(); }
  setVolumes(voice: number, music: number) {
    this.voiceVolume = voice; this.musicVolume = music;
    if (this.gain) this.gain.gain.value = music;
    for (const peer of this.peers.values()) {
      for (const audio of peer.audio) audio.volume = audio.dataset.voiceSource === 'music' ? music : voice;
    }
  }
  async enableSound() {
    await this.context?.resume();
    await Promise.all([...this.peers.values()].flatMap((peer) => peer.audio.map((audio) => audio.play())));
  }
  private disposePeer(peer: Peer) {
    clearTimeout(peer.timer);
    clearTimeout(peer.recoveryTimer);
    peer.generation++;
    peer.pc.onconnectionstatechange = null; peer.pc.onicecandidate = null; peer.pc.ontrack = null;
    peer.pc.close();
    for (const audio of peer.audio) { audio.pause(); audio.srcObject = null; audio.remove(); }
  }
  close() {
    this.closed = true;
    for (const peer of this.peers.values()) this.disposePeer(peer);
    this.peers.clear();
    this.mic = null;
    this.musicElement?.pause();
    if (this.musicElement) { this.musicElement.onended = null; this.musicElement.onerror = null; this.musicElement.removeAttribute('src'); }
    if (this.musicUrl) URL.revokeObjectURL(this.musicUrl);
    this.destination?.stream.getTracks().forEach((track) => track.stop());
    void this.context?.close();
  }
}