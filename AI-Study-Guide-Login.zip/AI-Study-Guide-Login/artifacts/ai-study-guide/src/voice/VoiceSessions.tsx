import { type FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check, ChevronDown, ChevronUp, Clipboard, Headphones, Mic, MicOff,
  Music2, Radio, ShieldAlert, Users, Volume2, X,
} from 'lucide-react';
import { useVoiceSession } from './use-voice-session';
import type { PeerStatus } from './types';
import './voice-session.css';

function roomIdFromInput(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return '';
  try {
    const url = new URL(trimmed, window.location.origin);
    return url.searchParams.get('voice') || trimmed;
  } catch {
    return trimmed;
  }
}

function connectionLabel(status: PeerStatus | undefined, self: boolean, connected: boolean) {
  if (self && connected) return 'You · connected';
  if (self) return 'You · room reconnecting';
  if (status === 'connected') return 'Connected';
  if (status === 'reconnecting') return 'Reconnecting';
  if (status === 'failed') return 'Connection failed';
  return 'Connecting';
}

export default function VoiceSessions() {
  const voice = useVoiceSession();
  const [open, setOpen] = useState(false);
  const [roomTitle, setRoomTitle] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [joinValue, setJoinValue] = useState('');
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'failed'>('idle');
  const fileRef = useRef<HTMLInputElement>(null);
  const copyFieldRef = useRef<HTMLInputElement>(null);
  const participants = voice.room?.participants ?? [];
  const sessionActive = voice.status !== 'idle' && Boolean(voice.room);
  const occupancy = `${participants.length} / ${voice.room?.maxParticipants ?? 6}`;
  const inviteLink = useMemo(() => {
    if (!voice.room) return '';
    const base = import.meta.env.BASE_URL.endsWith('/') ? import.meta.env.BASE_URL : `${import.meta.env.BASE_URL}/`;
    return `${window.location.origin}${base}whiteboard?voice=${encodeURIComponent(voice.room.id)}`;
  }, [voice.room]);

  useEffect(() => {
    if (voice.inviteRoomId) setJoinValue(voice.inviteRoomId);
  }, [voice.inviteRoomId]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!roomTitle.trim() || !displayName.trim()) return;
    await voice.createRoom(roomTitle.trim(), displayName.trim());
  }

  async function join(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const roomId = roomIdFromInput(joinValue);
    if (!roomId || !displayName.trim()) return;
    await voice.joinRoom(roomId, displayName.trim());
  }

  async function copyInvite() {
    if (!inviteLink) return;
    try {
      await navigator.clipboard.writeText(inviteLink);
      setCopyState('copied');
      window.setTimeout(() => setCopyState('idle'), 2400);
    } catch {
      setCopyState('failed');
      copyFieldRef.current?.focus();
      copyFieldRef.current?.select();
    }
  }

  async function depart(endRoom = false) {
    const message = voice.isHost
      ? 'Leaving will end this temporary room for everyone. Continue?'
      : 'Leave this study room?';
    if (!window.confirm(message)) return;
    if (endRoom && voice.isHost) await voice.endRoom();
    else await voice.leaveRoom();
  }

  return (
    <>
      {!open && (
        <button className={`voice-launch ${sessionActive ? 'has-room' : ''}`} type="button"
          onClick={() => setOpen(true)} aria-label={sessionActive ? 'Open live study room' : 'Open live study'}>
          <span className="voice-launch-mark"><Radio size={17} /></span>
          <span>{sessionActive ? <><strong>Study room live</strong><small>{voice.room?.name}</small></> : <><strong>Study together</strong><small>Start a live audio room</small></>}</span>
          {sessionActive && <i className="voice-live-dot" aria-label="Room active" />}
        </button>
      )}
      {open && (
        <aside className="voice-panel" role="region" aria-label="Live study room" aria-live="polite">
          <header className="voice-panel-head">
            <div className="voice-brand-mark"><Radio size={17} /></div>
            <div className="voice-panel-title">
              <span className="voice-eyebrow">{sessionActive ? 'LIVE STUDY ROOM' : 'NORSE · LIVE STUDY'}</span>
              <h2>{voice.room?.name || 'Study together'}</h2>
            </div>
            {sessionActive && <span className="voice-count"><Users size={13} /> {occupancy}</span>}
            <button className="voice-icon-button" type="button" onClick={() => setOpen(false)} aria-label="Close live study panel">
              <X size={17} />
            </button>
          </header>
          <div className="voice-panel-body">
            {voice.status === 'reconnecting' && (
              <div className="voice-audio-blocked" role="status">
                <div><strong>Reconnecting to the room…</strong>
                  <span>Existing audio stays on while we retry. You can still mute or leave.</span></div>
              </div>
            )}
            {voice.error && (
              <div className="voice-error" role="alert">
                <ShieldAlert size={16} /><span>{voice.error}</span>
                <button type="button" onClick={voice.clearError} aria-label="Dismiss error"><X size={14} /></button>
              </div>
            )}
            {voice.audioBlocked && (
              <div className="voice-audio-blocked" role="status">
                <div><strong>Sound is waiting for permission</strong><span>Tap once to hear voices and room music.</span></div>
                <button type="button" onClick={() => void voice.enableSound()}>Enable sound</button>
              </div>
            )}
            {!sessionActive ? (
              <div className="voice-entry">
                <div className="voice-intro">
                  <p>A small room for talking through the lecture, with optional host-streamed music.</p>
                  <span><Users size={14} /> Up to 6 people · microphone starts muted</span>
                </div>
                <form className="voice-form voice-create-form" onSubmit={create}>
                  <h3>Start a room</h3>
                  <label htmlFor="voice-room-title">Room title</label>
                  <input id="voice-room-title" value={roomTitle} onChange={(event) => setRoomTitle(event.target.value)} maxLength={72} placeholder="e.g. Observer pattern review" required />
                  <label htmlFor="voice-create-name">Your display name</label>
                  <input id="voice-create-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={40} placeholder="Name shown to your group" required />
                  <button className="voice-primary" type="submit" disabled={voice.busy}>
                    {voice.busy ? 'Starting room…' : 'Create study room'}
                  </button>
                </form>
                <div className="voice-form-divider"><span>or join an invitation</span></div>
                <form className="voice-form voice-join-form" onSubmit={join}>
                  <label htmlFor="voice-room-id">Room ID or invitation link</label>
                  <input id="voice-room-id" value={joinValue} onChange={(event) => setJoinValue(event.target.value)} placeholder="Paste a room ID or link" required />
                  <label htmlFor="voice-join-name">Your display name</label>
                  <input id="voice-join-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={40} placeholder="Name shown to your group" required />
                  <button className="voice-secondary" type="submit" disabled={voice.busy}>
                    {voice.busy ? 'Joining room…' : 'Join room'}
                  </button>
                </form>
                <p className="voice-join-note">Joining never turns on your microphone. Enable it when you’re ready.</p>
              </div>
            ) : (
              <div className="voice-active">
                <div className="voice-room-banner">
                  <span className="voice-live-pill"><i /> LIVE</span>
                  <div><strong>{voice.room?.name}</strong><span>Temporary room · no recording</span></div>
                </div>
                <section className="voice-roster" aria-labelledby="voice-roster-heading">
                  <div className="voice-section-title"><h3 id="voice-roster-heading">In this room</h3><span>{occupancy}</span></div>
                  {participants.length === 0 ? (
                    <div className="voice-empty-roster"><Users size={19} /><span>Waiting for the first participant…</span></div>
                  ) : (
                    <ul>
                      {participants.map((person) => {
                        const self = person.id === voice.participantId;
                        const peerStatus = self ? undefined : voice.peers[person.id];
                        const label = connectionLabel(peerStatus, self, voice.status === 'connected');
                        return (
                          <li key={person.id} className={`voice-person ${peerStatus === 'failed' ? 'is-failed' : ''} ${peerStatus === 'reconnecting' ? 'is-reconnecting' : ''}`}>
                            <span className="voice-avatar">{person.name.trim().slice(0, 1).toUpperCase() || '?'}</span>
                            <span className="voice-person-copy"><strong>{person.name}{self ? ' (you)' : ''}</strong><small>{label}{person.isHost ? ' · Host' : ''}</small></span>
                            <span className={`voice-peer-state ${peerStatus || (self ? voice.status : 'connecting')}`} aria-label={label} />
                            {person.micEnabled ? <Mic size={15} aria-label="Microphone on" /> : <MicOff size={15} aria-label="Microphone muted" />}
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </section>
                <div className="voice-mic-control">
                  <button className={`voice-mic-button ${voice.micEnabled ? 'mic-on' : ''}`} type="button"
                    onClick={() => void voice.toggleMic()} disabled={voice.micBusy || voice.busy}
                    aria-pressed={voice.micEnabled}>
                    {voice.micEnabled ? <Mic size={17} /> : <MicOff size={17} />}
                    <span>{voice.micBusy ? 'Updating microphone…' : voice.micEnabled ? 'Mute microphone' : 'Turn microphone on'}</span>
                    {!voice.micEnabled && <small>Muted</small>}
                  </button>
                  <p>Only you control your microphone. Permission is requested when you turn it on.</p>
                </div>
                <section className="voice-music" aria-labelledby="voice-music-heading">
                  <div className="voice-section-title"><h3 id="voice-music-heading"><Music2 size={15} /> Room music</h3>{voice.isHost && <span>Host controls</span>}</div>
                  {voice.isHost ? (
                    <>
                      <input ref={fileRef} className="voice-file-input" type="file" accept="audio/*" aria-label="Choose local music file" onChange={(event) => {
                        const file = event.currentTarget.files?.[0];
                        if (file) void voice.loadMusic(file);
                        event.currentTarget.value = '';
                      }} />
                      <div className="voice-music-host">
                        <div className="voice-track"><span className="voice-track-art"><Music2 size={16} /></span><span><strong>{voice.musicName || voice.room?.music?.title || 'Choose a track'}</strong><small>{voice.musicPlaying ? 'Playing for the room' : 'Stream music to the room'}</small></span></div>
                        <button className="voice-small-button" type="button" onClick={() => fileRef.current?.click()} disabled={voice.busy}>Choose file</button>
                      </div>
                      <button className="voice-play-button" type="button" onClick={() => void voice.toggleMusic()} disabled={voice.busy || (!voice.musicName && !voice.room?.music?.title)}>
                        {voice.musicPlaying ? 'Pause room music' : 'Play room music'}
                      </button>
                      <p className="voice-music-note">Music streams from the host’s device; the audio file is not uploaded.</p>
                    </>
                  ) : (
                    <div className="voice-track guest-track">
                      <span className="voice-track-art"><Music2 size={16} /></span>
                      <span><strong>{voice.room?.music?.title || 'No music selected'}</strong><small>{voice.room?.music?.playing ? 'Host is playing music' : 'Music is paused'}</small></span>
                      {voice.room?.music?.playing && <span className="voice-playing-bars" aria-label="Music playing"><i /><i /><i /></span>}
                    </div>
                  )}
                  <div className="voice-volume-row">
                    <label htmlFor="voice-volume"><Mic size={14} /><span>Voices</span><input id="voice-volume" type="range" min="0" max="1" step="0.01" value={voice.voiceVolume} onChange={(event) => voice.setVoiceVolume(Number(event.currentTarget.value))} /></label>
                    <label htmlFor="music-volume"><Volume2 size={14} /><span>Music</span><input id="music-volume" type="range" min="0" max="1" step="0.01" value={voice.musicVolume} onChange={(event) => voice.setMusicVolume(Number(event.currentTarget.value))} /></label>
                  </div>
                </section>
                <div className="voice-invite">
                  <div className="voice-section-title"><h3>Invite your group</h3><span>Share link</span></div>
                  <div className="voice-copy-row">
                    <input ref={copyFieldRef} aria-label="Invitation link" value={inviteLink} readOnly onFocus={(event) => event.currentTarget.select()} />
                    <button className="voice-small-button" type="button" onClick={() => void copyInvite()} aria-label="Copy invitation link">
                      {copyState === 'copied' ? <Check size={15} /> : <Clipboard size={15} />}
                      {copyState === 'copied' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  {copyState === 'failed' && <p className="voice-copy-error" role="alert">Could not copy automatically. The link is selected above; copy it manually.</p>}
                </div>
                <details className="voice-connection-details">
                  <summary>About this room <ChevronDown size={14} /></summary>
                  <ul>
                    <li>Key-free, direct WebRTC connections; restrictive networks may prevent a connection because there is no relay.</li>
                    <li>Rooms hold up to 6 people and end when the host leaves or the server restarts.</li>
                    <li>No recording, uploads, or shared whiteboard drawing. Only room audio and host-streamed music are live.</li>
                  </ul>
                </details>
                <div className="voice-leave-actions">
                  {voice.isHost && <button className="voice-end-button" type="button" onClick={() => void depart(true)} disabled={voice.busy}>End room</button>}
                  <button className={voice.isHost ? 'voice-leave-button' : 'voice-end-button'} type="button" onClick={() => void depart(false)} disabled={voice.busy}>
                    {voice.isHost ? 'Leave and end room' : 'Leave room'}
                  </button>
                </div>
              </div>
            )}
          </div>
          <footer className="voice-panel-foot">
            <span><Headphones size={13} /> Audio only. Your board stays on this device.</span>
            {voice.busy && <span className="voice-busy"><span /> Working…</span>}
          </footer>
        </aside>
      )}
      {sessionActive && !open && (
        <button className="voice-mini-status" type="button" onClick={() => setOpen(true)} aria-label="Return to live study controls">
          <span className="voice-live-dot" /> Live room <ChevronUp size={14} />
        </button>
      )}
    </>
  );
}