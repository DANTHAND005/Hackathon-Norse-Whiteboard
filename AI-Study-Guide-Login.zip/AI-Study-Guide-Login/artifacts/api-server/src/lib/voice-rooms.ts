import { createHash, randomBytes, randomUUID } from "node:crypto";
import type { VoiceEvent, VoiceMusic, VoiceParticipant, VoiceRoom } from "@workspace/api-zod";

const MAX_PEOPLE = 6;
const ROOM_LIFETIME = 6 * 60 * 60 * 1000;
const MEMBER_TIMEOUT = 180_000;
const MAX_EVENTS = 256;

export class VoiceError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

type Member = VoiceParticipant & {
  tokenHash: string;
  lastSeen: number;
  seq: number;
  events: VoiceEvent[];
};
type Room = {
  id: string; name: string; hostId: string; expires: number;
  music: VoiceMusic; members: Map<string, Member>;
};

function hash(token: string) { return createHash("sha256").update(token).digest("hex"); }
function cleanName(value: string) {
  const name = value.trim();
  if (!name) throw new VoiceError(400, "Enter a name first.");
  return name;
}

// Signaling only: no recordings, media files, board data, or persistent accounts.
// Deliberately ephemeral; a restart ends rooms rather than silently reconnecting.
export class VoiceRooms {
  private rooms = new Map<string, Room>();
  private limits = new Map<string, { count: number; expires: number }>();

  limit(key: string, max: number, duration: number) {
    const now = Date.now();
    if (this.limits.size > 1000) {
      for (const [id, entry] of this.limits) if (entry.expires <= now) this.limits.delete(id);
      if (this.limits.size > 2000) throw new VoiceError(429, "The session server is busy. Try again shortly.");
    }
    const entry = this.limits.get(key);
    if (!entry || entry.expires <= now) this.limits.set(key, { count: 1, expires: now + duration });
    else if (++entry.count > max) throw new VoiceError(429, "Too many requests. Wait a moment and try again.");
  }

  private prune() {
    const now = Date.now();
    for (const [id, room] of this.rooms) {
      const host = room.members.get(room.hostId);
      if (room.expires <= now || !host || now - host.lastSeen > MEMBER_TIMEOUT) {
        this.rooms.delete(id);
        continue;
      }
      for (const [memberId, member] of room.members) {
        if (now - member.lastSeen > MEMBER_TIMEOUT) room.members.delete(memberId);
      }
    }
  }

  private room(id: string) {
    this.prune();
    const room = this.rooms.get(id);
    if (!room) throw new VoiceError(404, "This session ended, expired, or its host left. Start a new session.");
    return room;
  }

  private snapshot(room: Room): VoiceRoom {
    return {
      id: room.id, name: room.name, hostId: room.hostId,
      participants: [...room.members.values()].map(({ id, name, isHost, micEnabled }) =>
        ({ id, name, isHost, micEnabled })),
      music: { ...room.music }, maxParticipants: MAX_PEOPLE,
      expiresAt: new Date(room.expires).toISOString(),
    };
  }

  private addMember(room: Room, name: string, isHost: boolean) {
    const token = randomBytes(32).toString("base64url");
    const member: Member = {
      id: randomUUID(), name: cleanName(name), isHost, micEnabled: false,
      tokenHash: hash(token), lastSeen: Date.now(), seq: 0, events: [],
    };
    room.members.set(member.id, member);
    if (isHost) room.hostId = member.id;
    return { room: this.snapshot(room), participantId: member.id, token };
  }

  create(name: string, displayName: string) {
    this.prune();
    if (this.rooms.size >= 100) throw new VoiceError(429, "All session slots are busy. Try again later.");
    const room: Room = {
      id: randomBytes(16).toString("base64url"), name: cleanName(name),
      hostId: "", expires: Date.now() + ROOM_LIFETIME,
      music: { title: null, playing: false }, members: new Map(),
    };
    const membership = this.addMember(room, displayName, true);
    this.rooms.set(room.id, room);
    return membership;
  }

  join(roomId: string, displayName: string) {
    const room = this.room(roomId);
    if (room.members.size >= MAX_PEOPLE) throw new VoiceError(409, "This session is full (6 people maximum).");
    return this.addMember(room, displayName, false);
  }

  private authorize(roomId: string, token: string) {
    const room = this.room(roomId);
    if (!/^[\w-]{43}$/.test(token)) throw new VoiceError(401, "Your session credential is missing or invalid.");
    const digest = hash(token);
    const member = [...room.members.values()].find((item) => item.tokenHash === digest);
    if (!member) throw new VoiceError(401, "Your session membership expired. Join again.");
    member.lastSeen = Date.now();
    return { room, member };
  }

  poll(roomId: string, token: string, after: number) {
    const { room, member } = this.authorize(roomId, token);
    this.limit(`poll:${member.id}`, 90, 60_000);
    if (after > member.seq || (member.events[0] && after < member.events[0].seq - 1)) {
      throw new VoiceError(409, "The connection fell too far behind. Leave and join the session again.");
    }
    member.events = member.events.filter((event) => event.seq > after);
    return { room: this.snapshot(room), events: [...member.events], cursor: member.seq };
  }

  signal(roomId: string, token: string, recipientId: string, kind: VoiceEvent["kind"], data: string) {
    const { room, member } = this.authorize(roomId, token);
    this.limit(`signal:${member.id}`, 180, 60_000);
    const recipient = room.members.get(recipientId);
    if (!recipient || recipient === member) throw new VoiceError(404, "That participant is no longer in the session.");
    if (kind === "candidate") {
      try {
        const candidate = JSON.parse(data);
        if (!candidate || typeof candidate.candidate !== "string" || candidate.candidate.length > 4096) {
          throw new Error("invalid");
        }
      } catch { throw new VoiceError(400, "Invalid connection candidate."); }
    } else if (!data.startsWith("v=0")) {
      throw new VoiceError(400, "Invalid connection description.");
    }
    recipient.events.push({ seq: ++recipient.seq, senderId: member.id, kind, data });
    if (recipient.events.length > MAX_EVENTS) recipient.events.shift();
  }

  update(roomId: string, token: string, input: { micEnabled?: boolean; music?: VoiceMusic }) {
    const { room, member } = this.authorize(roomId, token);
    this.limit(`state:${member.id}`, 60, 60_000);
    if (input.music && !member.isHost) throw new VoiceError(403, "Only the host can control music.");
    if (input.micEnabled !== undefined) member.micEnabled = input.micEnabled;
    if (input.music) {
      if (input.music.title && input.music.title.length > 200) throw new VoiceError(400, "Music title is too long.");
      room.music = { ...input.music };
    }
  }

  leave(roomId: string, token: string, end = false) {
    const { room, member } = this.authorize(roomId, token);
    if (end && !member.isHost) throw new VoiceError(403, "Only the host can end this session.");
    if (member.isHost) this.rooms.delete(roomId);
    else room.members.delete(member.id);
  }
}

export const voiceRooms = new VoiceRooms();