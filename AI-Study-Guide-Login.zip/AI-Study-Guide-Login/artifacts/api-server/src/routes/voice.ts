import { Router, type Request, type Response, type RequestHandler } from "express";
import {
  CreateVoiceRoomBody, CreateVoiceRoomResponse, JoinVoiceRoomBody, JoinVoiceRoomResponse,
  PollVoiceRoomBody, PollVoiceRoomResponse, SignalVoiceRoomBody, UpdateVoiceStateBody,
} from "@workspace/api-zod";
import { VoiceError, voiceRooms } from "../lib/voice-rooms";

const router = Router();

function parse<T>(schema: { parse(value: unknown): T }, value: unknown): T {
  try { return schema.parse(value); }
  catch { throw new VoiceError(400, "Invalid session request. Check the names and invitation."); }
}
function token(req: Request) { return req.get("authorization")?.replace(/^Bearer /, "") ?? ""; }
function roomId(req: Request) { return String(req.params.roomId); }
function run(fn: (req: Request, res: Response) => void): RequestHandler {
  return (req, res) => {
    try { fn(req, res); }
    catch (error) {
      if (error instanceof VoiceError) res.status(error.status).json({ error: error.message });
      else {
        req.log.error("Voice coordination failed");
        res.status(500).json({ error: "The session server could not complete this request." });
      }
    }
  };
}

router.use("/voice", (req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  res.removeHeader("Access-Control-Allow-Origin");
  const site = req.get("sec-fetch-site");
  if (site && site !== "same-origin" && site !== "none") {
    res.status(403).json({ error: "Open sessions from this website, not another site." });
    return;
  }
  if (["POST", "PATCH"].includes(req.method) && req.path !== "" &&
    !req.path.endsWith("/leave") && !req.path.endsWith("/end") &&
    !req.is("application/json")) {
    res.status(415).json({ error: "Session requests must use JSON." });
    return;
  }
  next();
});

router.post("/voice/rooms", run((req, res) => {
  voiceRooms.limit(`create:${req.ip ?? "connection"}`, 20, 600_000);
  const input = parse(CreateVoiceRoomBody, req.body);
  res.status(201).json(CreateVoiceRoomResponse.parse(voiceRooms.create(input.name, input.displayName)));
}));
router.post("/voice/rooms/:roomId/join", run((req, res) => {
  voiceRooms.limit(`join:${req.ip ?? "connection"}`, 60, 60_000);
  const input = parse(JoinVoiceRoomBody, req.body);
  res.json(JoinVoiceRoomResponse.parse(voiceRooms.join(roomId(req), input.displayName)));
}));
router.post("/voice/rooms/:roomId/poll", run((req, res) => {
  const input = parse(PollVoiceRoomBody, req.body);
  res.json(PollVoiceRoomResponse.parse(voiceRooms.poll(roomId(req), token(req), input.after)));
}));
router.post("/voice/rooms/:roomId/signal", run((req, res) => {
  const input = parse(SignalVoiceRoomBody, req.body);
  voiceRooms.signal(roomId(req), token(req), input.recipientId, input.kind, input.data);
  res.sendStatus(204);
}));
router.patch("/voice/rooms/:roomId/state", run((req, res) => {
  voiceRooms.update(roomId(req), token(req), parse(UpdateVoiceStateBody, req.body));
  res.sendStatus(204);
}));
router.post("/voice/rooms/:roomId/leave", run((req, res) => {
  voiceRooms.leave(roomId(req), token(req));
  res.sendStatus(204);
}));
router.post("/voice/rooms/:roomId/end", run((req, res) => {
  voiceRooms.leave(roomId(req), token(req), true);
  res.sendStatus(204);
}));

export default router;